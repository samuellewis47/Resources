package wake.model;

import java.awt.AWTException;
import java.awt.Robot;
import java.util.Random;

public class Wake implements Runnable {
	
	private Thread thread;
	private String threadName;
	private volatile boolean running = true;
	
	public Wake(String name) {
      threadName = name;
	}

	public void run() {
		while (running) {
			wake();
		}	
	}
	
	public void start() {
		if (thread == null) {
			thread = new Thread(this, threadName);
			thread.start ();
		}
	}
	
	public void wake(){
		
		Robot hal;
		try {
			hal = new Robot();
			Random random = new Random();
			hal.delay(1000 * 60);
            int x = random.nextInt() % 640;
            int y = random.nextInt() % 480;
            hal.mouseMove(x,y);
            
		} catch (AWTException e) {
			e.getMessage();
		}
	}

}
