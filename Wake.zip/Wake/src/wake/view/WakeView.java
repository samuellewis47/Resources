package wake.view;

import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.WindowConstants;

import wake.model.Wake;

public class WakeView extends Frame implements ActionListener{

	private static final long serialVersionUID = 1L;
	
	JLabel message; 
	JButton startBtn;
	JButton closeBtn;
	transient Wake wakeThread = new Wake("Thread-Sx47");
	
	public WakeView(){  
				
		message=new JLabel();  
		message.setBounds(70,50,150,30);      
        
		startBtn=new JButton("Start Shaky!");  
		startBtn.setBounds(70,50,150,30);  
		startBtn.addActionListener(this);

		closeBtn=new JButton("Close Application!");  
		closeBtn.setBounds(70,100,150,30);  
		closeBtn.addActionListener(this);
        
        add(startBtn);
        add(closeBtn);
        add(message); 
        
        setSize(300,150);  
        setVisible(true);
        setTitle("Wake | Sx47");
    }
	
	public void actionPerformed(ActionEvent e) {  
    	if (e.getSource()==startBtn)
        {
    		remove(startBtn);
    		try {				
    			wakeThread.start();
    		} catch (Exception e1) {
    			Thread.currentThread().interrupt();
    		}
        }

    	if (e.getSource()==closeBtn)
        {
    		System.exit(WindowConstants.DISPOSE_ON_CLOSE);
    		System.exit(WindowConstants.EXIT_ON_CLOSE);
        }
    	
    }

}
