package wake.controller;

import wake.view.WakeView;

public class WakeController {

	public static void main(String[] args) {
		new WakeView();	
	}
}
