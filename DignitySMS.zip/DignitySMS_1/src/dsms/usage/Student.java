/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsms.usage;

/**
 *
 * @author admin
 */
public class Student 
    {
        String student_name = null;
        Student()
            {
                
            }
       
        
        public void setName(String name)
         {
            this.student_name = name;
         }

        public String getName()
         {
           return student_name;
        }
    }


