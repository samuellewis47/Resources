/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dsms.model;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.*;
import com.itextpdf.text.*;
import com.lowagie.text.Cell;
import dsms.utility.DbConnector;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author admin
 */
public class PrintProgressReport {
    
    ResultSet rs1=null,rs2=null,rs3=null,rs4=null,rs5=null,rs6=null,rs7=null,rs8=null,rs9=null;
    Connection con=null;
    Statement st1=null,st2=null,st3=null, st4=null,st5=null,st6=null,st7=null,st8=null,st9=null;
    
    public PrintProgressReport()
    {
        
    }
    public InputStream inputStream;
    private static Font catFontBold = new Font(Font.FontFamily.TIMES_ROMAN, 32,Font.BOLD);
    private static Font catFont = new Font(Font.FontFamily.TIMES_ROMAN, 18,Font.BOLD);
    private static Font redFont = new Font(Font.FontFamily.TIMES_ROMAN, 12,Font.NORMAL, BaseColor.RED);
    private static Font subFont = new Font(Font.FontFamily.TIMES_ROMAN, 16,Font.BOLD);
    private static Font smallBold = new Font(Font.FontFamily.TIMES_ROMAN, 12,Font.BOLD);
    private static Font extrasmallBold = new Font(Font.FontFamily.TIMES_ROMAN, 8,Font.BOLD);
    private static Font normalFont = new Font(Font.FontFamily.TIMES_ROMAN, 12,Font.NORMAL);
    
    //Method which prints Junior Semester 1st Marksheet
    //<editor-fold defaultstate="collapsed" desc="PPR Junior Sem 1">
    public void printProgressReportJunior_Sem1(int std_id, String gr_no, String report_type, String name, String roll_no, String Stand, String std_div,
            String fname, String focc, String mname, String mocc, String mtongue, String medium, String dob, String age, String phone,
            String email, String prHno, String prBldgNo, String prStrName, String prCity, String prDistrict, String prState, 
            String semester, String english, String marathi, String hindi, String maths, String gscience, String evs,
            String hstory, String arts, String computer, String pt, String gk, String music, String specificProg, 
            String likinghobby, String needtoimprove, String passedPromoted, String junewd, String julywd, String augwd,
            String sepwd, String octwd, String novwd, String junepd, String julypd, String augpd, String seppd, String octpd,
            String novpd)
    {
        
        String imagePath = "D:\\Workspace_Netbeans\\DignitySMS_1\\images\\header.jpg";
        String imagePath2 = "D:\\Workspace_Netbeans\\DignitySMS_1\\images\\stu_image.jpg";
        System.out.println(report_type);
        System.out.println(semester);
        Image image = null;
        Image image2 = null;
        try
        {
            // Make stuff for the document
            
            // Makes the Image
            OutputStream file = new FileOutputStream(new File("C:\\Users\\admin\\Desktop\\Progressreport\\Report_"+std_id+"_"+gr_no+"_"+semester+"_"+report_type+".pdf"));
            image = Image.getInstance(imagePath);
            image2 = Image.getInstance(imagePath2);
            //image.setAlignment(Element.ALIGN_CENTER);
            //image.setAbsolutePosition(50f, 700f);
            //image.scaleAbsolute(500f, 100f);
            
            // **1 Holy Cross Header Image**
            PdfPTable table = new PdfPTable(1);
            table.setWidthPercentage(100);
            //table.setWidths(new float[]{2.6f,1.6f});
            table.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(image);
            table.setHorizontalAlignment(50);
            Paragraph p1= new Paragraph();
            p1.add(table);
            
            // **2 Spacer**
            Paragraph p3 = new Paragraph();
            addEmptyLine(p3, 1);
            
            // **3 This table contains the main Title**
            PdfPTable table1 = new PdfPTable(1);
            table1.setWidthPercentage(70);
            //table.setWidths(new float[]{2.6f,1.6f});
            table1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table1.setHorizontalAlignment(50);
            PdfPCell cell = new PdfPCell(new Phrase("CONTINUOS CUMULATIVE EVALUATION PROGRESS REPORT 2016-2017"));
            cell.setVerticalAlignment(Element.ALIGN_CENTER);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table1.addCell(cell);
            Paragraph p2= new Paragraph();
            p2.add(table1);
            
            // **71 Spacer**
            Paragraph p71 = new Paragraph();
            addEmptyLine(p71, 1);
            
            // **70 Student's Photo**
            PdfPTable table60 = new PdfPTable(1);
            table60.setWidthPercentage(30);
            //table.setWidths(new float[]{2.6f,1.6f});
            table60.setHorizontalAlignment(Element.ALIGN_CENTER);
            table60.addCell(image2);
            table60.setHorizontalAlignment(50);
            Paragraph p70= new Paragraph();
            p70.add(table60);
            
            // **4 Spacer**
            Paragraph p5 = new Paragraph();
            addEmptyLine(p5, 2);
            
            // **6 Table contains first line from Report card**
            PdfPTable table2 = new PdfPTable(2);
            table2.setWidthPercentage(100);
            PdfPCell cellOne = new PdfPCell(new Phrase("Name: "+name+""));
            PdfPCell cellTwo = new PdfPCell(new Phrase("Roll No: "+roll_no+""));
            cellOne.setBorder(Rectangle.NO_BORDER);
            cellTwo.setBorder(Rectangle.NO_BORDER);
            //cellTwo.setHorizontalAlignment(Element.ALIGN_CENTER);
            table2.addCell(cellOne);
            table2.addCell(cellTwo);
            Paragraph p4= new Paragraph();
            p4.add(table2);
            
            // **7 Table contains secound line from Report card**
            PdfPTable table3 = new PdfPTable(2);
            table3.setWidthPercentage(100);
            PdfPCell t3_cell1 = new PdfPCell(new Phrase("STD: "+Stand+""));
            PdfPCell t3_cell2 = new PdfPCell(new Phrase("Division: "+std_div+""));
            //    PdfPCell t3_cell3 = new PdfPCell(new Phrase("G.R. No: "+gr_no+""));
            t3_cell1.setBorder(Rectangle.NO_BORDER);
            t3_cell2.setBorder(Rectangle.NO_BORDER);
            //t3_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            //    t3_cell3.setBorder(Rectangle.NO_BORDER);
            table3.addCell(t3_cell1);
            table3.addCell(t3_cell2);
            //    table3.addCell(t3_cell3);
            Paragraph p6= new Paragraph();
            p6.add(table3);
            
            // **8 Table contains third line from Report card**
            PdfPTable table4 = new PdfPTable(2);
            table4.setWidthPercentage(100);
            PdfPCell t4_cell1 = new PdfPCell(new Phrase("Father's Name: "+fname+""));
            PdfPCell t4_cell2 = new PdfPCell(new Phrase("Profession: "+focc+""));
            t4_cell1.setBorder(Rectangle.NO_BORDER);
            t4_cell2.setBorder(Rectangle.NO_BORDER);
            //t4_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table4.addCell(t4_cell1);
            table4.addCell(t4_cell2);
            Paragraph p7= new Paragraph();
            p7.add(table4);
            
            // **9 Table contains fourth line from Report card**
            PdfPTable table5 = new PdfPTable(2);
            table5.setWidthPercentage(100);
            PdfPCell t5_cell1 = new PdfPCell(new Phrase("Mother's Name: "+mname+""));
            PdfPCell t5_cell2 = new PdfPCell(new Phrase("Profession: "+mocc+""));
            t5_cell1.setBorder(Rectangle.NO_BORDER);
            t5_cell2.setBorder(Rectangle.NO_BORDER);
            //t5_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table5.addCell(t5_cell1);
            table5.addCell(t5_cell2);
            Paragraph p8= new Paragraph();
            p8.add(table5);
            
            // **10 Table contains fifth line from Report card**
            PdfPTable table6 = new PdfPTable(2);
            table6.setWidthPercentage(100);
            PdfPCell t6_cell1 = new PdfPCell(new Phrase("Mother Tongue: "+mtongue+""));
            PdfPCell t6_cell2 = new PdfPCell(new Phrase("Medium: "+medium+""));
            t6_cell1.setBorder(Rectangle.NO_BORDER);
            t6_cell2.setBorder(Rectangle.NO_BORDER);
            //t6_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table6.addCell(t6_cell1);
            table6.addCell(t6_cell2);
            Paragraph p9= new Paragraph();
            p9.add(table6);
            
            // **11 Table contains sixth line from Report card**
            PdfPTable table7 = new PdfPTable(2);
            table7.setWidthPercentage(100);
            PdfPCell t7_cell1 = new PdfPCell(new Phrase("Date of Birth: "+dob+""));
            PdfPCell t7_cell2 = new PdfPCell(new Phrase("Age: "+age+""));
            t7_cell1.setBorder(Rectangle.NO_BORDER);
            t7_cell2.setBorder(Rectangle.NO_BORDER);
            //t7_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            table7.addCell(t7_cell1);
            table7.addCell(t7_cell2);
            Paragraph p10= new Paragraph();
            p10.add(table7);
            
            // **12 Table contains seventh line from Report card**
            PdfPTable table8 = new PdfPTable(1);
            table8.setWidthPercentage(100);
            PdfPCell t8_cell1 = new PdfPCell(new Phrase("Address: "+prHno+" "+prBldgNo+" "+prStrName+""));
            t8_cell1.setBorder(Rectangle.NO_BORDER);
            table8.addCell(t8_cell1);
            Paragraph p11= new Paragraph();
            p11.add(table8);
            
            // **13 Table contains eighth line from Report card**
            PdfPTable table9 = new PdfPTable(1);
            table9.setWidthPercentage(100);
            PdfPCell t9_cell1 = new PdfPCell(new Phrase("Telephone No: "+phone+""));
            t9_cell1.setBorder(Rectangle.NO_BORDER);
            table9.addCell(t9_cell1);
            Paragraph p12= new Paragraph();
            p12.add(table9);
            
            // **14 Table contains ninth line from Report card**
            PdfPTable table10 = new PdfPTable(1);
            table10.setWidthPercentage(100);
            PdfPCell t10_cell1 = new PdfPCell(new Phrase("Email Id: "+email+""));
            t10_cell1.setBorder(Rectangle.NO_BORDER);
            table10.addCell(t10_cell1);
            Paragraph p13= new Paragraph();
            p13.add(table10);
            
            // **15 Adds New Page
            
            // **16 Table contains title of new page - First Semester**
            PdfPTable table11 = new PdfPTable(1);
            table11.setWidthPercentage(100);
            PdfPCell t11_cell1 = new PdfPCell(new Phrase("First Semester"));
            t11_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t11_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table11.addCell(t11_cell1);
            Paragraph p14= new Paragraph();
            p14.add(table11);
            
            // **17 Table contains coulmn names**
            PdfPTable table12 = new PdfPTable(3);
            table12.setWidthPercentage(100);
            PdfPCell t12_cell1 = new PdfPCell(new Phrase("Subject"));
            PdfPCell t12_cell2 = new PdfPCell(new Phrase("Marks"));
            PdfPCell t12_cell3 = new PdfPCell(new Phrase("Descriptive Detail"));
            t12_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t12_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t12_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t12_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t12_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t12_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table12.addCell(t12_cell1);
            table12.addCell(t12_cell2);
            table12.addCell(t12_cell3);
            Paragraph p15= new Paragraph();
            p15.add(table12);
            
            // **18 Table contains subject English and space for marks**
            PdfPTable table13 = new PdfPTable(3);
            table13.setWidthPercentage(100);
            PdfPCell t13_cell1 = new PdfPCell(new Phrase("English"));
            PdfPCell t13_cell2 = new PdfPCell(new Phrase(english));
            PdfPCell t13_cell3 = new PdfPCell(new Phrase("Specific Progress"));
            t13_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t13_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t13_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t13_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t13_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t13_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table13.addCell(t13_cell1);
            table13.addCell(t13_cell2);
            table13.addCell(t13_cell3);
            Paragraph p16= new Paragraph();
            p16.add(table13);
            
            // **19 Table contains subject Marathi and space for marks**
            PdfPTable table14 = new PdfPTable(3);
            table14.setWidthPercentage(100);
            PdfPCell t14_cell1 = new PdfPCell(new Phrase("Marathi"));
            PdfPCell t14_cell2 = new PdfPCell(new Phrase(marathi));
            PdfPCell t14_cell3 = new PdfPCell(new Phrase(specificProg));
            t14_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t14_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t14_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t14_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t14_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t14_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table14.addCell(t14_cell1);
            table14.addCell(t14_cell2);
            table14.addCell(t14_cell3);
            Paragraph p17= new Paragraph();
            p17.add(table14);
            
            // **20 Table contains subject Hindi and space for marks**
            PdfPTable table15 = new PdfPTable(3);
            table15.setWidthPercentage(100);
            PdfPCell t15_cell1 = new PdfPCell(new Phrase("Hindi"));
            PdfPCell t15_cell2 = new PdfPCell(new Phrase(hindi));
            PdfPCell t15_cell3 = new PdfPCell(new Phrase("   "));
            t15_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t15_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t15_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t15_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t15_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t15_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table15.addCell(t15_cell1);
            table15.addCell(t15_cell2);
            table15.addCell(t15_cell3);
            Paragraph p18= new Paragraph();
            p18.add(table15);
            
            // **21 Table contains subject Maths and space for marks**
            PdfPTable table16 = new PdfPTable(3);
            table16.setWidthPercentage(100);
            PdfPCell t16_cell1 = new PdfPCell(new Phrase("Maths"));
            PdfPCell t16_cell2 = new PdfPCell(new Phrase(maths));
            PdfPCell t16_cell3 = new PdfPCell(new Phrase("   "));
            t16_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t16_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t16_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t16_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t16_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t16_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table16.addCell(t16_cell1);
            table16.addCell(t16_cell2);
            table16.addCell(t16_cell3);
            Paragraph p19= new Paragraph();
            p19.add(table16);
            
            // **22 Table contains subject G. Science and space for marks**
            PdfPTable table17 = new PdfPTable(3);
            table17.setWidthPercentage(100);
            PdfPCell t17_cell1 = new PdfPCell(new Phrase("G. Science"));
            PdfPCell t17_cell2 = new PdfPCell(new Phrase(gscience));
            PdfPCell t17_cell3 = new PdfPCell(new Phrase("Liking / Hobby"));
            t17_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t17_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t17_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t17_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t17_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t17_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table17.addCell(t17_cell1);
            table17.addCell(t17_cell2);
            table17.addCell(t17_cell3);
            Paragraph p20= new Paragraph();
            p20.add(table17);
            
            // **23 Table contains subject EVS and space for marks**
            PdfPTable table18 = new PdfPTable(3);
            table18.setWidthPercentage(100);
            PdfPCell t18_cell1 = new PdfPCell(new Phrase("EVS"));
            PdfPCell t18_cell2 = new PdfPCell(new Phrase(evs));
            PdfPCell t18_cell3 = new PdfPCell(new Phrase(likinghobby));
            t18_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t18_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t18_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t18_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t18_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t18_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table18.addCell(t18_cell1);
            table18.addCell(t18_cell2);
            table18.addCell(t18_cell3);
            Paragraph p21= new Paragraph();
            p21.add(table18);
            
            // **24 Table contains subject History / Geography and space for marks**
            PdfPTable table19 = new PdfPTable(3);
            table19.setWidthPercentage(100);
            PdfPCell t19_cell1 = new PdfPCell(new Phrase("History / Geography"));
            PdfPCell t19_cell2 = new PdfPCell(new Phrase(hstory));
            PdfPCell t19_cell3 = new PdfPCell(new Phrase("   "));
            t19_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t19_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t19_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t19_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t19_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t19_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table19.addCell(t19_cell1);
            table19.addCell(t19_cell2);
            table19.addCell(t19_cell3);
            Paragraph p22= new Paragraph();
            p22.add(table19);
            
            // **25 Table contains subject Art / Craft and space for marks**
            PdfPTable table20 = new PdfPTable(3);
            table20.setWidthPercentage(100);
            PdfPCell t20_cell1 = new PdfPCell(new Phrase("Art / Craft"));
            PdfPCell t20_cell2 = new PdfPCell(new Phrase(arts));
            PdfPCell t20_cell3 = new PdfPCell(new Phrase("   "));
            t20_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t20_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t20_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t20_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t20_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t20_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table20.addCell(t20_cell1);
            table20.addCell(t20_cell2);
            table20.addCell(t20_cell3);
            Paragraph p23= new Paragraph();
            p23.add(table20);
            
            // **26 Table contains subject Computer and space for marks**
            PdfPTable table21 = new PdfPTable(3);
            table21.setWidthPercentage(100);
            PdfPCell t21_cell1 = new PdfPCell(new Phrase("Computer"));
            PdfPCell t21_cell2 = new PdfPCell(new Phrase(computer));
            PdfPCell t21_cell3 = new PdfPCell(new Phrase("Need to Improve In"));
            t21_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t21_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t21_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t21_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t21_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t21_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table21.addCell(t21_cell1);
            table21.addCell(t21_cell2);
            table21.addCell(t21_cell3);
            Paragraph p24= new Paragraph();
            p24.add(table21);
            
            // **27 Table contains subject P. T. and space for marks**
            PdfPTable table22 = new PdfPTable(3);
            table22.setWidthPercentage(100);
            PdfPCell t22_cell1 = new PdfPCell(new Phrase("P. T."));
            PdfPCell t22_cell2 = new PdfPCell(new Phrase(pt));
            PdfPCell t22_cell3 = new PdfPCell(new Phrase(needtoimprove));
            t22_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t22_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t22_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t22_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t22_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t22_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table22.addCell(t22_cell1);
            table22.addCell(t22_cell2);
            table22.addCell(t22_cell3);
            Paragraph p25= new Paragraph();
            p25.add(table22);
            
            // **28 Table contains subject G.K / V. Edu. and space for marks**
            PdfPTable table23 = new PdfPTable(3);
            table23.setWidthPercentage(100);
            PdfPCell t23_cell1 = new PdfPCell(new Phrase("G.K / V. Edu."));
            PdfPCell t23_cell2 = new PdfPCell(new Phrase(gk));
            PdfPCell t23_cell3 = new PdfPCell(new Phrase("   "));
            t23_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t23_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t23_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t23_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t23_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t23_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table23.addCell(t23_cell1);
            table23.addCell(t23_cell2);
            table23.addCell(t23_cell3);
            Paragraph p26= new Paragraph();
            p26.add(table23);
            
            // **29 Table contains subject Music and space for marks**
            PdfPTable table24 = new PdfPTable(3);
            table24.setWidthPercentage(100);
            PdfPCell t24_cell1 = new PdfPCell(new Phrase("Music"));
            PdfPCell t24_cell2 = new PdfPCell(new Phrase(music));
            PdfPCell t24_cell3 = new PdfPCell(new Phrase("   "));
            t24_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t24_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t24_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t24_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t24_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t24_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table24.addCell(t24_cell1);
            table24.addCell(t24_cell2);
            table24.addCell(t24_cell3);
            Paragraph p27= new Paragraph();
            p27.add(table24);
            
            // **47 Spacer**
            Paragraph p46 = new Paragraph();
            addEmptyLine(p46, 1);
            
            // **45 Table contains passed and promoted to line**
            PdfPTable table39 = new PdfPTable(2);
            table39.setWidthPercentage(100);
            PdfPCell t39_cell1 = new PdfPCell(new Phrase("Passed and promoted to: "));
            PdfPCell t39_cell2 = new PdfPCell(new Phrase(passedPromoted));
            t39_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t39_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t39_cell1.setBorder(Rectangle.NO_BORDER);
            t39_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t39_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t39_cell2.setBorder(Rectangle.NO_BORDER);
            table39.addCell(t39_cell1);
            table39.addCell(t39_cell2);
            Paragraph p42= new Paragraph();
            p42.add(table39);
            
            // **47 Spacer**
            Paragraph p44 = new Paragraph();
            addEmptyLine(p44, 2);
            
            // **46 Table contains signatures** Table 40, 41, 42 are unused.
            PdfPTable table43 = new PdfPTable(3);
            table43.setWidthPercentage(100);
            PdfPCell t43_cell1 = new PdfPCell(new Phrase("Teacher's Sign"));
            PdfPCell t43_cell2 = new PdfPCell(new Phrase("Principal's Sign"));
            PdfPCell t43_cell3 = new PdfPCell(new Phrase("Parent's Sign"));
            t43_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t43_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t43_cell1.setBorder(Rectangle.NO_BORDER);
            t43_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t43_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t43_cell2.setBorder(Rectangle.NO_BORDER);
            t43_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t43_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            t43_cell3.setBorder(Rectangle.NO_BORDER);
            table43.addCell(t43_cell1);
            table43.addCell(t43_cell2);
            table43.addCell(t43_cell3);
            Paragraph p43= new Paragraph();
            p43.add(table43);
            
            // **30 Adds New Page
            
            // **31 Table contains title of new page - Second Semester**
            PdfPTable table25 = new PdfPTable(1);
            table25.setWidthPercentage(100);
            PdfPCell t25_cell1 = new PdfPCell(new Phrase("Second Semester"));
            t25_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t25_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table25.addCell(t25_cell1);
            Paragraph p28= new Paragraph();
            p28.add(table25);
            
            // **32 Table contains coulmn names**
            PdfPTable table26 = new PdfPTable(3);
            table26.setWidthPercentage(100);
            PdfPCell t26_cell1 = new PdfPCell(new Phrase("Subject"));
            PdfPCell t26_cell2 = new PdfPCell(new Phrase("Marks"));
            PdfPCell t26_cell3 = new PdfPCell(new Phrase("Descriptive Detail"));
            t26_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t26_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t26_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t26_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t26_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t26_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table26.addCell(t26_cell1);
            table26.addCell(t26_cell2);
            table26.addCell(t26_cell3);
            Paragraph p29= new Paragraph();
            p29.add(table26);
            
            // **33 Table contains subject English and space for marks**
            PdfPTable table27 = new PdfPTable(3);
            table27.setWidthPercentage(100);
            PdfPCell t27_cell1 = new PdfPCell(new Phrase("English"));
            PdfPCell t27_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t27_cell3 = new PdfPCell(new Phrase("   "));
            t27_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t27_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t27_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t27_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t27_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t27_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table27.addCell(t27_cell1);
            table27.addCell(t27_cell2);
            table27.addCell(t27_cell3);
            Paragraph p30= new Paragraph();
            p30.add(table27);
            
            // **34 Table contains subject Marathi and space for marks**
            PdfPTable table28 = new PdfPTable(3);
            table28.setWidthPercentage(100);
            PdfPCell t28_cell1 = new PdfPCell(new Phrase("Marathi"));
            PdfPCell t28_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t28_cell3 = new PdfPCell(new Phrase("   "));
            t28_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t28_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t28_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t28_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t28_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t28_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table28.addCell(t28_cell1);
            table28.addCell(t28_cell2);
            table28.addCell(t28_cell3);
            Paragraph p31= new Paragraph();
            p31.add(table28);
            
            // **35 Table contains subject Hindi and space for marks**
            PdfPTable table29 = new PdfPTable(3);
            table29.setWidthPercentage(100);
            PdfPCell t29_cell1 = new PdfPCell(new Phrase("Hindi"));
            PdfPCell t29_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t29_cell3 = new PdfPCell(new Phrase("   "));
            t29_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t29_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t29_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t29_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t29_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t29_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table29.addCell(t29_cell1);
            table29.addCell(t29_cell2);
            table29.addCell(t29_cell3);
            Paragraph p32= new Paragraph();
            p32.add(table29);
            
            // **36 Table contains subject Maths and space for marks**
            PdfPTable table30 = new PdfPTable(3);
            table30.setWidthPercentage(100);
            PdfPCell t30_cell1 = new PdfPCell(new Phrase("Maths"));
            PdfPCell t30_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t30_cell3 = new PdfPCell(new Phrase("   "));
            t30_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t30_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t30_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t30_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t30_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t30_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table30.addCell(t30_cell1);
            table30.addCell(t30_cell2);
            table30.addCell(t30_cell3);
            Paragraph p33= new Paragraph();
            p33.add(table30);
            
            // **37 Table contains subject G. Science and space for marks**
            PdfPTable table31 = new PdfPTable(3);
            table31.setWidthPercentage(100);
            PdfPCell t31_cell1 = new PdfPCell(new Phrase("G. Science"));
            PdfPCell t31_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t31_cell3 = new PdfPCell(new Phrase("   "));
            t31_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t31_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t31_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t31_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t31_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t31_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table31.addCell(t31_cell1);
            table31.addCell(t31_cell2);
            table31.addCell(t31_cell3);
            Paragraph p34= new Paragraph();
            p34.add(table31);
            
            // **38 Table contains subject EVS and space for marks**
            PdfPTable table32 = new PdfPTable(3);
            table32.setWidthPercentage(100);
            PdfPCell t32_cell1 = new PdfPCell(new Phrase("EVS"));
            PdfPCell t32_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t32_cell3 = new PdfPCell(new Phrase("   "));
            t32_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t32_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t32_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t32_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t32_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t32_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table32.addCell(t32_cell1);
            table32.addCell(t32_cell2);
            table32.addCell(t32_cell3);
            Paragraph p35= new Paragraph();
            p35.add(table32);
            
            // **39 Table contains subject History / Geography and space for marks**
            PdfPTable table33 = new PdfPTable(3);
            table33.setWidthPercentage(100);
            PdfPCell t33_cell1 = new PdfPCell(new Phrase("History / Geography"));
            PdfPCell t33_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t33_cell3 = new PdfPCell(new Phrase("   "));
            t33_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t33_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t33_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t33_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t33_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t33_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table33.addCell(t33_cell1);
            table33.addCell(t33_cell2);
            table33.addCell(t33_cell3);
            Paragraph p36= new Paragraph();
            p36.add(table33);
            
            // **40 Table contains subject Art / Craft and space for marks**
            PdfPTable table34 = new PdfPTable(3);
            table34.setWidthPercentage(100);
            PdfPCell t34_cell1 = new PdfPCell(new Phrase("Art / Craft"));
            PdfPCell t34_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t34_cell3 = new PdfPCell(new Phrase("   "));
            t34_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t34_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t34_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t34_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t34_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t34_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table34.addCell(t34_cell1);
            table34.addCell(t34_cell2);
            table34.addCell(t34_cell3);
            Paragraph p37= new Paragraph();
            p37.add(table34);
            
            // **41 Table contains subject Computer and space for marks**
            PdfPTable table35 = new PdfPTable(3);
            table35.setWidthPercentage(100);
            PdfPCell t35_cell1 = new PdfPCell(new Phrase("Computer"));
            PdfPCell t35_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t35_cell3 = new PdfPCell(new Phrase("   "));
            t35_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t35_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t35_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t35_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t35_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t35_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table35.addCell(t35_cell1);
            table35.addCell(t35_cell2);
            table35.addCell(t35_cell3);
            Paragraph p38= new Paragraph();
            p38.add(table35);
            
            // **42 Table contains subject P. T. and space for marks**
            PdfPTable table36 = new PdfPTable(3);
            table36.setWidthPercentage(100);
            PdfPCell t36_cell1 = new PdfPCell(new Phrase("P. T."));
            PdfPCell t36_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t36_cell3 = new PdfPCell(new Phrase("   "));
            t36_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t36_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t36_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t36_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t36_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t36_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table36.addCell(t36_cell1);
            table36.addCell(t36_cell2);
            table36.addCell(t36_cell3);
            Paragraph p39= new Paragraph();
            p39.add(table36);
            
            // **43 Table contains subject G.K / V. Edu. and space for marks**
            PdfPTable table37 = new PdfPTable(3);
            table37.setWidthPercentage(100);
            PdfPCell t37_cell1 = new PdfPCell(new Phrase("G.K / V. Edu."));
            PdfPCell t37_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t37_cell3 = new PdfPCell(new Phrase("   "));
            t37_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t37_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t37_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t37_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t37_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t37_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table37.addCell(t37_cell1);
            table37.addCell(t37_cell2);
            table37.addCell(t37_cell3);
            Paragraph p40= new Paragraph();
            p40.add(table37);
            
            // **44 Table contains subject Music and space for marks**
            PdfPTable table38 = new PdfPTable(3);
            table38.setWidthPercentage(100);
            PdfPCell t38_cell1 = new PdfPCell(new Phrase("Music"));
            PdfPCell t38_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t38_cell3 = new PdfPCell(new Phrase("   "));
            t38_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t38_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t38_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t38_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t38_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t38_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table38.addCell(t38_cell1);
            table38.addCell(t38_cell2);
            table38.addCell(t38_cell3);
            Paragraph p41= new Paragraph();
            p41.add(table38);
            
            // **59 Spacer**
            Paragraph p59 = new Paragraph();
            addEmptyLine(p59, 1);
            
            // **60 Table contains passed and promoted to line**
            PdfPTable table59 = new PdfPTable(2);
            table59.setWidthPercentage(100);
            PdfPCell t59_cell1 = new PdfPCell(new Phrase("Passed and promoted to: "));
            PdfPCell t59_cell2 = new PdfPCell(new Phrase(" "));
            t59_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t59_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t59_cell1.setBorder(Rectangle.NO_BORDER);
            t59_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t59_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t59_cell2.setBorder(Rectangle.NO_BORDER);
            table59.addCell(t59_cell1);
            table59.addCell(t59_cell2);
            Paragraph p60= new Paragraph();
            p60.add(table59);
            
            // **61 Table contains Attendance compulsory line**
            PdfPTable table61 = new PdfPTable(1);
            table61.setWidthPercentage(100);
            PdfPCell t61_cell1 = new PdfPCell(new Phrase("Attendance on Reopening day is compulsory"));
            t61_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t61_cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
            t61_cell1.setBorder(Rectangle.NO_BORDER);
            table61.addCell(t61_cell1);
            Paragraph p61= new Paragraph();
            p61.add(table61);
            
            // **62 Spacer**
            Paragraph p62 = new Paragraph();
            addEmptyLine(p62, 2);
            
            // **63 Table contains signatures**
            PdfPTable table63 = new PdfPTable(3);
            table63.setWidthPercentage(100);
            PdfPCell t63_cell1 = new PdfPCell(new Phrase("Teacher's Sign"));
            PdfPCell t63_cell2 = new PdfPCell(new Phrase("Principal's Sign"));
            PdfPCell t63_cell3 = new PdfPCell(new Phrase("Parent's Sign"));
            t63_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t63_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t63_cell1.setBorder(Rectangle.NO_BORDER);
            t63_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t63_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t63_cell2.setBorder(Rectangle.NO_BORDER);
            t63_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t63_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            t63_cell3.setBorder(Rectangle.NO_BORDER);
            table63.addCell(t63_cell1);
            table63.addCell(t63_cell2);
            table63.addCell(t63_cell3);
            Paragraph p63= new Paragraph();
            p63.add(table63);
            
            // **49 Adds New Page
            
            // **50 Table contains months**
            PdfPTable table50 = new PdfPTable(13);
            table50.setWidthPercentage(100);
            PdfPCell t50_cell1 = new PdfPCell(new Phrase("Month"));
            PdfPCell t50_cell2 = new PdfPCell(new Phrase("June"));
            PdfPCell t50_cell3 = new PdfPCell(new Phrase("July"));
            PdfPCell t50_cell4 = new PdfPCell(new Phrase("Aug"));
            PdfPCell t50_cell5 = new PdfPCell(new Phrase("Sep"));
            PdfPCell t50_cell6 = new PdfPCell(new Phrase("Oct"));
            PdfPCell t50_cell7 = new PdfPCell(new Phrase("Nov"));
            PdfPCell t50_cell8 = new PdfPCell(new Phrase("Dec"));
            PdfPCell t50_cell9 = new PdfPCell(new Phrase("Jan"));
            PdfPCell t50_cell10 = new PdfPCell(new Phrase("Feb"));
            PdfPCell t50_cell11 = new PdfPCell(new Phrase("Mar"));
            PdfPCell t50_cell12 = new PdfPCell(new Phrase("Apr"));
            PdfPCell t50_cell13 = new PdfPCell(new Phrase("May"));
            t50_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell4.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell5.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell6.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell7.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell8.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell9.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell10.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell11.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell12.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell13.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
            table50.addCell(t50_cell1);
            table50.addCell(t50_cell2);
            table50.addCell(t50_cell3);
            table50.addCell(t50_cell4);
            table50.addCell(t50_cell5);
            table50.addCell(t50_cell6);
            table50.addCell(t50_cell7);
            table50.addCell(t50_cell8);
            table50.addCell(t50_cell9);
            table50.addCell(t50_cell10);
            table50.addCell(t50_cell11);
            table50.addCell(t50_cell12);
            table50.addCell(t50_cell13);
            Paragraph p50= new Paragraph();
            p50.add(table50);
            
            // **51 Table contains Working Days**
            PdfPTable table51 = new PdfPTable(13);
            table51.setWidthPercentage(100);
            PdfPCell t51_cell1 = new PdfPCell(new Phrase("Working Days"));
            PdfPCell t51_cell2 = new PdfPCell(new Phrase(junewd));
            PdfPCell t51_cell3 = new PdfPCell(new Phrase(julywd));
            PdfPCell t51_cell4 = new PdfPCell(new Phrase(augwd));
            PdfPCell t51_cell5 = new PdfPCell(new Phrase(sepwd));
            PdfPCell t51_cell6 = new PdfPCell(new Phrase(octwd));
            PdfPCell t51_cell7 = new PdfPCell(new Phrase(novwd));
            PdfPCell t51_cell8 = new PdfPCell(new Phrase(" "));
            PdfPCell t51_cell9 = new PdfPCell(new Phrase(" "));
            PdfPCell t51_cell10 = new PdfPCell(new Phrase(" "));
            PdfPCell t51_cell11 = new PdfPCell(new Phrase(" "));
            PdfPCell t51_cell12 = new PdfPCell(new Phrase(" "));
            PdfPCell t51_cell13 = new PdfPCell(new Phrase(" "));
            t51_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell4.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell5.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell6.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell7.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell8.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell9.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell10.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell11.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell12.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell13.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
            table51.addCell(t51_cell1);
            table51.addCell(t51_cell2);
            table51.addCell(t51_cell3);
            table51.addCell(t51_cell4);
            table51.addCell(t51_cell5);
            table51.addCell(t51_cell6);
            table51.addCell(t51_cell7);
            table51.addCell(t51_cell8);
            table51.addCell(t51_cell9);
            table51.addCell(t51_cell10);
            table51.addCell(t51_cell11);
            table51.addCell(t51_cell12);
            table51.addCell(t51_cell13);
            Paragraph p51= new Paragraph();
            p51.add(table51);
            
            // **52 Table contains Present Days**
            PdfPTable table52 = new PdfPTable(13);
            table52.setWidthPercentage(100);
            PdfPCell t52_cell1 = new PdfPCell(new Phrase("Present Days"));
            PdfPCell t52_cell2 = new PdfPCell(new Phrase(junepd));
            PdfPCell t52_cell3 = new PdfPCell(new Phrase(julypd));
            PdfPCell t52_cell4 = new PdfPCell(new Phrase(augpd));
            PdfPCell t52_cell5 = new PdfPCell(new Phrase(seppd));
            PdfPCell t52_cell6 = new PdfPCell(new Phrase(octpd));
            PdfPCell t52_cell7 = new PdfPCell(new Phrase(novpd));
            PdfPCell t52_cell8 = new PdfPCell(new Phrase(" "));
            PdfPCell t52_cell9 = new PdfPCell(new Phrase(" "));
            PdfPCell t52_cell10 = new PdfPCell(new Phrase(" "));
            PdfPCell t52_cell11 = new PdfPCell(new Phrase(" "));
            PdfPCell t52_cell12 = new PdfPCell(new Phrase(" "));
            PdfPCell t52_cell13 = new PdfPCell(new Phrase(" "));
            t52_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell4.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell5.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell6.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell7.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell8.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell9.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell10.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell11.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell12.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell13.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
            table52.addCell(t52_cell1);
            table52.addCell(t52_cell2);
            table52.addCell(t52_cell3);
            table52.addCell(t52_cell4);
            table52.addCell(t52_cell5);
            table52.addCell(t52_cell6);
            table52.addCell(t52_cell7);
            table52.addCell(t52_cell8);
            table52.addCell(t52_cell9);
            table52.addCell(t52_cell10);
            table52.addCell(t52_cell11);
            table52.addCell(t52_cell12);
            table52.addCell(t52_cell13);
            Paragraph p52= new Paragraph();
            p52.add(table52);
           
            // **53 Table contains Class Teacher's Sign**
            PdfPTable table53 = new PdfPTable(3);
            table53.setWidthPercentage(100);
            PdfPCell t53_cell1 = new PdfPCell(new Phrase("Class Teacher's Sign"));
            PdfPCell t53_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t53_cell3 = new PdfPCell(new Phrase("   "));
            t53_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t53_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t53_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t53_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t53_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t53_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table53.addCell(t53_cell1);
            table53.addCell(t53_cell2);
            table53.addCell(t53_cell3);
            Paragraph p53= new Paragraph();
            p53.add(table53);
            
            // **54 Table contains Class Teacher's Sign**
            PdfPTable table54 = new PdfPTable(3);
            table54.setWidthPercentage(100);
            PdfPCell t54_cell1 = new PdfPCell(new Phrase("Parent's Sign"));
            PdfPCell t54_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t54_cell3 = new PdfPCell(new Phrase("   "));
            t54_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t54_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t54_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t54_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t54_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t54_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table54.addCell(t54_cell1);
            table54.addCell(t54_cell2);
            table54.addCell(t54_cell3);
            Paragraph p54= new Paragraph();
            p54.add(table54);
            
            // **55 Table contains Principal's Sign**
            PdfPTable table55 = new PdfPTable(3);
            table55.setWidthPercentage(100);
            PdfPCell t55_cell1 = new PdfPCell(new Phrase("Principal's Sign"));
            PdfPCell t55_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t55_cell3 = new PdfPCell(new Phrase("   "));
            t55_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t55_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t55_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t55_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t55_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t55_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table55.addCell(t55_cell1);
            table55.addCell(t55_cell2);
            table55.addCell(t55_cell3);
            Paragraph p55= new Paragraph();
            p55.add(table55);
            
            // **56 Spacer**
            Paragraph p56 = new Paragraph();
            addEmptyLine(p56, 3);
            
            // **57 Table contains Assessment of the Marks**
            PdfPTable table57 = new PdfPTable(10);
            table57.setWidthPercentage(100);
            PdfPCell t57_cell1 = new PdfPCell(new Phrase("Assessment of the Marks"));
            PdfPCell t57_cell2 = new PdfPCell(new Phrase("91% to 100%"));
            PdfPCell t57_cell3 = new PdfPCell(new Phrase("81% to 90%"));
            PdfPCell t57_cell4 = new PdfPCell(new Phrase("71% to 80%"));
            PdfPCell t57_cell5 = new PdfPCell(new Phrase("61% to 70%"));
            PdfPCell t57_cell6 = new PdfPCell(new Phrase("51% to 60%"));
            PdfPCell t57_cell7 = new PdfPCell(new Phrase("41% to 50%"));
            PdfPCell t57_cell8 = new PdfPCell(new Phrase("31% to 40%"));
            PdfPCell t57_cell9 = new PdfPCell(new Phrase("21% to 30%"));
            PdfPCell t57_cell10 = new PdfPCell(new Phrase("Less then 20%"));
            t57_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell4.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell5.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell6.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell7.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell8.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell9.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell10.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
            table57.addCell(t57_cell1);
            table57.addCell(t57_cell2);
            table57.addCell(t57_cell3);
            table57.addCell(t57_cell4);
            table57.addCell(t57_cell5);
            table57.addCell(t57_cell6);
            table57.addCell(t57_cell7);
            table57.addCell(t57_cell8);
            table57.addCell(t57_cell9);
            table57.addCell(t57_cell10);
            Paragraph p57= new Paragraph();
            p57.add(table57);
            
            // **58 Table contains Grade**
            PdfPTable table58 = new PdfPTable(10);
            table58.setWidthPercentage(100);
            PdfPCell t58_cell1 = new PdfPCell(new Phrase("Grade"));
            PdfPCell t58_cell2 = new PdfPCell(new Phrase("A-1"));
            PdfPCell t58_cell3 = new PdfPCell(new Phrase("A-2"));
            PdfPCell t58_cell4 = new PdfPCell(new Phrase("B-1"));
            PdfPCell t58_cell5 = new PdfPCell(new Phrase("B-2"));
            PdfPCell t58_cell6 = new PdfPCell(new Phrase("C-1"));
            PdfPCell t58_cell7 = new PdfPCell(new Phrase("C-2"));
            PdfPCell t58_cell8 = new PdfPCell(new Phrase("D"));
            PdfPCell t58_cell9 = new PdfPCell(new Phrase("E-1"));
            PdfPCell t58_cell10 = new PdfPCell(new Phrase("E-2"));
            t58_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell4.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell5.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell6.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell7.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell8.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell9.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell10.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
            table58.addCell(t58_cell1);
            table58.addCell(t58_cell2);
            table58.addCell(t58_cell3);
            table58.addCell(t58_cell4);
            table58.addCell(t58_cell5);
            table58.addCell(t58_cell6);
            table58.addCell(t58_cell7);
            table58.addCell(t58_cell8);
            table58.addCell(t58_cell9);
            table58.addCell(t58_cell10);
            Paragraph p58= new Paragraph();
            p58.add(table58);
            
            // Makes a new document and opens it
            Document document = new Document(PageSize.A5);
            PdfWriter.getInstance(document,file);
            document.open();
            
            // Add stuff to the document
            document.add(p1);           // **1 Holy Cross Header Image**
            document.add(p3);           // **2 Spacer**
            document.add(p2);           // **3 This table contains the main Title**
            document.add(p71);           // **71 Spacer**
            document.add(p70);           // **70 Student's Photo**
            document.add(p5);           // **4 Spacer**
            document.add(p4);           // **6 Table contains first line from Report card**
            document.add(p6);           // **7 Table contains secound line from Report card**
            document.add(p7);           // **8 Table contains third line from Report card**
            document.add(p8);           // **9 Table contains fourth line from Report card**
            document.add(p9);           // **10 Table contains fifth line from Report card**
            document.add(p10);          // **11 Table contains sixth line from Report card**
            document.add(p11);          // **12 Table contains seventh line from Report card**
            document.add(p12);          // **13 Table contains eighth line from Report card**
            document.add(p13);          // **14 Table contains ninth line from Report card**
            
            document.newPage();         // **15 Adds New Page
            document.add(p14);          // **16 Table contains title of new page - First Semester**
            document.add(p15);          // **17 Table contains coulmn names**
            document.add(p16);          // **18 Table contains subject English and space for marks**
            document.add(p17);          // **19 Table contains subject Marathi and space for marks**
            document.add(p18);          // **20 Table contains subject Hindi and space for marks**
            document.add(p19);          // **21 Table contains subject Maths and space for marks**
            document.add(p20);          // **22 Table contains subject G. Science and space for marks**
            document.add(p21);          // **23 Table contains subject EVS and space for marks**
            document.add(p22);          // **24 Table contains subject His/Geo and space for marks**
            document.add(p23);          // **25 Table contains subject Art / Craft and space for marks**
            document.add(p24);          // **26 Table contains subject Computer and space for marks**
            document.add(p25);          // **27 Table contains subject PT Science and space for marks**
            document.add(p26);          // **28 Table contains subject GK Science and space for marks**
            document.add(p27);          // **29 Table contains subject Music and space for marks**
            document.add(p46);          // **48 Spacer**
            document.add(p42);          // **45 Table contains passed and promoted to line**
            document.add(p44);          // **47 Spacer**
            document.add(p43);          // **46 Signatures 
            
            document.newPage();         // **30 Adds New Page
            document.add(p28);          // **31 Table contains title of new page - First Semester**
            document.add(p29);          // **32 Table contains coulmn names**
            document.add(p30);          // **33 Table contains subject English and space for marks**
            document.add(p31);          // **34 Table contains subject Marathi and space for marks**
            document.add(p32);          // **35 Table contains subject Hindi and space for marks**
            document.add(p33);          // **36 Table contains subject Maths and space for marks**
            document.add(p34);          // **37 Table contains subject G. Science and space for marks**
            document.add(p35);          // **38 Table contains subject EVS and space for marks**
            document.add(p36);          // **39 Table contains subject His/Geo and space for marks**
            document.add(p37);          // **40 Table contains subject Art / Craft and space for marks**
            document.add(p38);          // **41 Table contains subject Computer and space for marks**
            document.add(p39);          // **42 Table contains subject PT Science and space for marks**
            document.add(p40);          // **43 Table contains subject GK Science and space for marks**
            document.add(p41);          // **44 Table contains subject Music and space for marks**
            document.add(p59);          // **59 Spacer**
            document.add(p60);          // **60 Table contains passed and promoted to line**
            document.add(p61);          // **61 Table contains Attendance compulsory line**
            document.add(p62);          // **62 Spacer**
            document.add(p63);          // **63 Table contains signatures**    
            
            document.newPage();         // **49 Adds New Page
            document.add(p50);          // **50 Table contains months**
            document.add(p51);          // **51 Table contains Working Days**
            document.add(p52);          // **52 Table contains Present Days**
            document.add(p53);          // **53 Table contains Class Teacher's Sign**
            document.add(p54);          // **54 Table contains Parent's Sign**
            document.add(p55);          // **55 Table contains Principal's Sign**
            document.add(p56);          // **56 Spacer**
            document.add(p57);          // **57 Table contains Assessment of the Marks**
            document.add(p58);          // **58 Table contains Grade**
            
            // Closes the document
            document.close();
            file.close();
            
            //printProgressReport_JR_FirstSem();
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
    }
//</editor-fold>
   
    //Method which prints Junior Semester 2nd Marksheet
    //<editor-fold defaultstate="collapsed" desc="PPR Junior Sem 2">
    public void printProgressReportJunior_Sem2(int std_id, String gr_no, String report_type, String name, String roll_no, String Stand, String std_div,
            String fname, String focc, String mname, String mocc, String mtongue, String medium, String dob, String age, String phone,
            String email, String prHno, String prBldgNo, String prStrName, String prCity, String prDistrict, String prState, 
            String semester, String english, String marathi, String hindi, String maths, String gscience, String evs,
            String hstory, String arts, String computer, String pt, String gk, String music, String specificProg, 
            String likinghobby, String needtoimprove, String passedPromoted, String decwd, String janwd, String febwd, String marwd,
            String aprwd, String maywd, String decpd, String janpd, String febpd, String marpd, String aprpd, String maypd)
    {
        String sql ="SELECT * FROM jr_prg_rpt_sem_first WHERE student_id = "+std_id;
        
        String english_s2 = null; 
        String  marathi_s2 = null; 
        String  hindi_s2 = null;
        String  maths_s2 = null;
        String  gscience_s2 = null;
        String  evs_s2 = null;
        String  historyGeog_s2 = null; 
        String  artCraft_s2 = null;
        String  computer_s2 = null;
        String  pt_s2 = null;
        String  gkVed_s2 = null;
        String  music_s2 = null;
        String  specificProgress_s2 = null; 
        String  likingHobby_s2 = null;
        String  needtoimprovein_s2 = null;
        String  passesdAndPromotedTo_s2 = null;
        
        String  junewd_s2 = null;
        String  julywd_s2 = null;
        String  augwd_s2 = null;
        String  sepwd_s2 = null;
        String  octwd_s2 = null;
        String  novwd_s2 = null;
        String  junepd_s2 = null;
        String  julypd_s2 = null;
        String  augpd_s2 = null;
        String  seppd_s2 = null;
        String  octpd_s2 = null;
        String  novpd_s2 = null;
        
        try
        {
            DbConnector dbc = new DbConnector();
            Connection con= dbc.dbcon();
            st2=con.createStatement();
            rs2= st2.executeQuery(sql);
            while(rs2.next())
            {
                english_s2 = rs2.getString(1);
                marathi_s2 = rs2.getString(2);
                hindi_s2 = rs2.getString(3);
                maths_s2 = rs2.getString(4);
                gscience_s2 = rs2.getString(5);
                evs_s2 = rs2.getString(6);
                historyGeog_s2= rs2.getString(7);
                artCraft_s2 = rs2.getString(8);
                computer_s2 = rs2.getString(9);
                pt_s2 = rs2.getString(10);
                gkVed_s2 = rs2.getString(11);
                music_s2 = rs2.getString(12);
                specificProgress_s2 = rs2.getString(13);
                likingHobby_s2 = rs2.getString(14);
                needtoimprovein_s2 = rs2.getString(15);
                passesdAndPromotedTo_s2 = rs2.getString(16);
                
                junewd_s2 = rs2.getString(20);
                julywd_s2 = rs2.getString(21);
                augwd_s2 = rs2.getString(22);
                sepwd_s2 = rs2.getString(23);
                octwd_s2 = rs2.getString(24);
                novwd_s2 = rs2.getString(25);
                junepd_s2 = rs2.getString(26);
                julypd_s2 = rs2.getString(27);
                augpd_s2 = rs2.getString(28);
                seppd_s2 = rs2.getString(29);
                octpd_s2 = rs2.getString(30);
                novpd_s2 = rs2.getString(31);
                //20 - 31
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                if(con!=null)
                {
                    con.close();
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }        // TODO add your handl
        
        String imagePath = "D:\\Workspace_Netbeans\\DignitySMS_1\\images\\header.jpg";
        String imagePath2 = "D:\\Workspace_Netbeans\\DignitySMS_1\\images\\stu_image.jpg";
        System.out.println(report_type);
        System.out.println(semester);
        Image image = null;
        Image image2 = null;
        try
        {
            // Make stuff for the document
            
            // Makes the Image
            OutputStream file = new FileOutputStream(new File("C:\\Users\\admin\\Desktop\\Progressreport\\Report_"+std_id+"_"+gr_no+"_"+semester+"_"+report_type+".pdf"));
            image = Image.getInstance(imagePath);
            image2 = Image.getInstance(imagePath2);
            //image.setAlignment(Element.ALIGN_CENTER);
            //image.setAbsolutePosition(50f, 700f);
            //image.scaleAbsolute(500f, 100f);
            
            // **1 Holy Cross Header Image**
            PdfPTable table = new PdfPTable(1);
            table.setWidthPercentage(100);
            //table.setWidths(new float[]{2.6f,1.6f});
            table.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(image);
            table.setHorizontalAlignment(50);
            Paragraph p1= new Paragraph();
            p1.add(table);
            
            // **2 Spacer**
            Paragraph p3 = new Paragraph();
            addEmptyLine(p3, 1);
            
            // **3 This table contains the main Title**
            PdfPTable table1 = new PdfPTable(1);
            table1.setWidthPercentage(70);
            //table.setWidths(new float[]{2.6f,1.6f});
            table1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table1.setHorizontalAlignment(50);
            PdfPCell cell = new PdfPCell(new Phrase("CONTINUOS CUMULATIVE EVALUATION PROGRESS REPORT 2016-2017"));
            cell.setVerticalAlignment(Element.ALIGN_CENTER);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table1.addCell(cell);
            Paragraph p2= new Paragraph();
            p2.add(table1);
            
            // **71 Spacer**
            Paragraph p71 = new Paragraph();
            addEmptyLine(p71, 1);
            
            // **70 Student's Photo**
            PdfPTable table60 = new PdfPTable(1);
            table60.setWidthPercentage(30);
            //table.setWidths(new float[]{2.6f,1.6f});
            table60.setHorizontalAlignment(Element.ALIGN_CENTER);
            table60.addCell(image2);
            table60.setHorizontalAlignment(50);
            Paragraph p70= new Paragraph();
            p70.add(table60);
            
            // **4 Spacer**
            Paragraph p5 = new Paragraph();
            addEmptyLine(p5, 2);
            
            // **5 Student's Photo**
            
            // **6 Table contains first line from Report card**
            PdfPTable table2 = new PdfPTable(2);
            table2.setWidthPercentage(100);
            PdfPCell cellOne = new PdfPCell(new Phrase("Name: "+name+""));
            PdfPCell cellTwo = new PdfPCell(new Phrase("Roll No: "+roll_no+""));
            cellOne.setBorder(Rectangle.NO_BORDER);
            cellTwo.setBorder(Rectangle.NO_BORDER);
            table2.addCell(cellOne);
            table2.addCell(cellTwo);
            Paragraph p4= new Paragraph();
            p4.add(table2);
            
            // **7 Table contains secound line from Report card**
            PdfPTable table3 = new PdfPTable(2);
            table3.setWidthPercentage(100);
            PdfPCell t3_cell1 = new PdfPCell(new Phrase("STD: "+Stand+""));
            PdfPCell t3_cell2 = new PdfPCell(new Phrase("Division: "+std_div+""));
            //    PdfPCell t3_cell3 = new PdfPCell(new Phrase("G.R. No: "+gr_no+""));
            t3_cell1.setBorder(Rectangle.NO_BORDER);
            t3_cell2.setBorder(Rectangle.NO_BORDER);
            //    t3_cell3.setBorder(Rectangle.NO_BORDER);
            table3.addCell(t3_cell1);
            table3.addCell(t3_cell2);
            //    table3.addCell(t3_cell3);
            Paragraph p6= new Paragraph();
            p6.add(table3);
            
            // **8 Table contains third line from Report card**
            PdfPTable table4 = new PdfPTable(2);
            table4.setWidthPercentage(100);
            PdfPCell t4_cell1 = new PdfPCell(new Phrase("Father's Name: "+fname+""));
            PdfPCell t4_cell2 = new PdfPCell(new Phrase("Profession: "+focc+""));
            t4_cell1.setBorder(Rectangle.NO_BORDER);
            t4_cell2.setBorder(Rectangle.NO_BORDER);
            table4.addCell(t4_cell1);
            table4.addCell(t4_cell2);
            Paragraph p7= new Paragraph();
            p7.add(table4);
            
            // **9 Table contains fourth line from Report card**
            PdfPTable table5 = new PdfPTable(2);
            table5.setWidthPercentage(100);
            PdfPCell t5_cell1 = new PdfPCell(new Phrase("Mother's Name: "+mname+""));
            PdfPCell t5_cell2 = new PdfPCell(new Phrase("Profession: "+mocc+""));
            t5_cell1.setBorder(Rectangle.NO_BORDER);
            t5_cell2.setBorder(Rectangle.NO_BORDER);
            table5.addCell(t5_cell1);
            table5.addCell(t5_cell2);
            Paragraph p8= new Paragraph();
            p8.add(table5);
            
            // **10 Table contains fifth line from Report card**
            PdfPTable table6 = new PdfPTable(2);
            table6.setWidthPercentage(100);
            PdfPCell t6_cell1 = new PdfPCell(new Phrase("Mother Tongue: "+mtongue+""));
            PdfPCell t6_cell2 = new PdfPCell(new Phrase("Medium: "+medium+""));
            t6_cell1.setBorder(Rectangle.NO_BORDER);
            t6_cell2.setBorder(Rectangle.NO_BORDER);
            table6.addCell(t6_cell1);
            table6.addCell(t6_cell2);
            Paragraph p9= new Paragraph();
            p9.add(table6);
            
            // **11 Table contains sixth line from Report card**
            PdfPTable table7 = new PdfPTable(2);
            table7.setWidthPercentage(100);
            PdfPCell t7_cell1 = new PdfPCell(new Phrase("Date of Birth: "+dob+""));
            PdfPCell t7_cell2 = new PdfPCell(new Phrase("Age: "+age+""));
            t7_cell1.setBorder(Rectangle.NO_BORDER);
            t7_cell2.setBorder(Rectangle.NO_BORDER);
            table7.addCell(t7_cell1);
            table7.addCell(t7_cell2);
            Paragraph p10= new Paragraph();
            p10.add(table7);
            
            // **12 Table contains seventh line from Report card**
            PdfPTable table8 = new PdfPTable(1);
            table8.setWidthPercentage(100);
            PdfPCell t8_cell1 = new PdfPCell(new Phrase("Address: "+prHno+" "+prBldgNo+" "+prStrName+""));
            t8_cell1.setBorder(Rectangle.NO_BORDER);
            table8.addCell(t8_cell1);
            Paragraph p11= new Paragraph();
            p11.add(table8);
            
            // **13 Table contains eighth line from Report card**
            PdfPTable table9 = new PdfPTable(1);
            table9.setWidthPercentage(100);
            PdfPCell t9_cell1 = new PdfPCell(new Phrase("Telephone No: "+phone+""));
            t9_cell1.setBorder(Rectangle.NO_BORDER);
            table9.addCell(t9_cell1);
            Paragraph p12= new Paragraph();
            p12.add(table9);
            
            // **14 Table contains ninth line from Report card**
            PdfPTable table10 = new PdfPTable(1);
            table10.setWidthPercentage(100);
            PdfPCell t10_cell1 = new PdfPCell(new Phrase("Email Id: "+email+""));
            t10_cell1.setBorder(Rectangle.NO_BORDER);
            table10.addCell(t10_cell1);
            Paragraph p13= new Paragraph();
            p13.add(table10);
            
            // **15 Adds New Page
            
            // **16 Table contains title of new page - First Semester**
            PdfPTable table11 = new PdfPTable(1);
            table11.setWidthPercentage(100);
            PdfPCell t11_cell1 = new PdfPCell(new Phrase("First Semester"));
            t11_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t11_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table11.addCell(t11_cell1);
            Paragraph p14= new Paragraph();
            p14.add(table11);
            
            // **17 Table contains coulmn names**
            PdfPTable table12 = new PdfPTable(3);
            table12.setWidthPercentage(100);
            PdfPCell t12_cell1 = new PdfPCell(new Phrase("Subject"));
            PdfPCell t12_cell2 = new PdfPCell(new Phrase("Marks"));
            PdfPCell t12_cell3 = new PdfPCell(new Phrase("Descriptive Detail"));
            t12_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t12_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t12_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t12_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t12_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t12_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table12.addCell(t12_cell1);
            table12.addCell(t12_cell2);
            table12.addCell(t12_cell3);
            Paragraph p15= new Paragraph();
            p15.add(table12);
            
            // **18 Table contains subject English and space for marks**
            PdfPTable table13 = new PdfPTable(3);
            table13.setWidthPercentage(100);
            PdfPCell t13_cell1 = new PdfPCell(new Phrase("English"));
            PdfPCell t13_cell2 = new PdfPCell(new Phrase(english_s2));
            PdfPCell t13_cell3 = new PdfPCell(new Phrase("Specific Progress"));
            t13_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t13_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t13_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t13_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t13_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t13_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table13.addCell(t13_cell1);
            table13.addCell(t13_cell2);
            table13.addCell(t13_cell3);
            Paragraph p16= new Paragraph();
            p16.add(table13);
            
            // **19 Table contains subject Marathi and space for marks**
            PdfPTable table14 = new PdfPTable(3);
            table14.setWidthPercentage(100);
            PdfPCell t14_cell1 = new PdfPCell(new Phrase("Marathi"));
            PdfPCell t14_cell2 = new PdfPCell(new Phrase(marathi_s2));
            PdfPCell t14_cell3 = new PdfPCell(new Phrase(specificProgress_s2));
            t14_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t14_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t14_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t14_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t14_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t14_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table14.addCell(t14_cell1);
            table14.addCell(t14_cell2);
            table14.addCell(t14_cell3);
            Paragraph p17= new Paragraph();
            p17.add(table14);
            
            // **20 Table contains subject Hindi and space for marks**
            PdfPTable table15 = new PdfPTable(3);
            table15.setWidthPercentage(100);
            PdfPCell t15_cell1 = new PdfPCell(new Phrase("Hindi"));
            PdfPCell t15_cell2 = new PdfPCell(new Phrase(hindi_s2));
            PdfPCell t15_cell3 = new PdfPCell(new Phrase("   "));
            t15_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t15_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t15_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t15_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t15_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t15_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table15.addCell(t15_cell1);
            table15.addCell(t15_cell2);
            table15.addCell(t15_cell3);
            Paragraph p18= new Paragraph();
            p18.add(table15);
            
            // **21 Table contains subject Maths and space for marks**
            PdfPTable table16 = new PdfPTable(3);
            table16.setWidthPercentage(100);
            PdfPCell t16_cell1 = new PdfPCell(new Phrase("Maths"));
            PdfPCell t16_cell2 = new PdfPCell(new Phrase(maths_s2));
            PdfPCell t16_cell3 = new PdfPCell(new Phrase("   "));
            t16_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t16_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t16_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t16_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t16_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t16_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table16.addCell(t16_cell1);
            table16.addCell(t16_cell2);
            table16.addCell(t16_cell3);
            Paragraph p19= new Paragraph();
            p19.add(table16);
            
            // **22 Table contains subject G. Science and space for marks**
            PdfPTable table17 = new PdfPTable(3);
            table17.setWidthPercentage(100);
            PdfPCell t17_cell1 = new PdfPCell(new Phrase("G. Science"));
            PdfPCell t17_cell2 = new PdfPCell(new Phrase(gscience_s2));
            PdfPCell t17_cell3 = new PdfPCell(new Phrase("Liking / Hobby"));
            t17_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t17_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t17_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t17_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t17_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t17_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table17.addCell(t17_cell1);
            table17.addCell(t17_cell2);
            table17.addCell(t17_cell3);
            Paragraph p20= new Paragraph();
            p20.add(table17);
            
            // **23 Table contains subject EVS and space for marks**
            PdfPTable table18 = new PdfPTable(3);
            table18.setWidthPercentage(100);
            PdfPCell t18_cell1 = new PdfPCell(new Phrase("EVS"));
            PdfPCell t18_cell2 = new PdfPCell(new Phrase(evs_s2));
            PdfPCell t18_cell3 = new PdfPCell(new Phrase(likingHobby_s2));
            t18_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t18_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t18_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t18_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t18_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t18_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table18.addCell(t18_cell1);
            table18.addCell(t18_cell2);
            table18.addCell(t18_cell3);
            Paragraph p21= new Paragraph();
            p21.add(table18);
            
            // **24 Table contains subject History / Geography and space for marks**
            PdfPTable table19 = new PdfPTable(3);
            table19.setWidthPercentage(100);
            PdfPCell t19_cell1 = new PdfPCell(new Phrase("History / Geography"));
            PdfPCell t19_cell2 = new PdfPCell(new Phrase(historyGeog_s2));
            PdfPCell t19_cell3 = new PdfPCell(new Phrase("   "));
            t19_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t19_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t19_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t19_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t19_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t19_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table19.addCell(t19_cell1);
            table19.addCell(t19_cell2);
            table19.addCell(t19_cell3);
            Paragraph p22= new Paragraph();
            p22.add(table19);
            
            // **25 Table contains subject Art / Craft and space for marks**
            PdfPTable table20 = new PdfPTable(3);
            table20.setWidthPercentage(100);
            PdfPCell t20_cell1 = new PdfPCell(new Phrase("Art / Craft"));
            PdfPCell t20_cell2 = new PdfPCell(new Phrase(artCraft_s2));
            PdfPCell t20_cell3 = new PdfPCell(new Phrase("   "));
            t20_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t20_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t20_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t20_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t20_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t20_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table20.addCell(t20_cell1);
            table20.addCell(t20_cell2);
            table20.addCell(t20_cell3);
            Paragraph p23= new Paragraph();
            p23.add(table20);
            
            // **26 Table contains subject Computer and space for marks**
            PdfPTable table21 = new PdfPTable(3);
            table21.setWidthPercentage(100);
            PdfPCell t21_cell1 = new PdfPCell(new Phrase("Computer"));
            PdfPCell t21_cell2 = new PdfPCell(new Phrase(computer_s2));
            PdfPCell t21_cell3 = new PdfPCell(new Phrase("Need to Improve In"));
            t21_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t21_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t21_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t21_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t21_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t21_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table21.addCell(t21_cell1);
            table21.addCell(t21_cell2);
            table21.addCell(t21_cell3);
            Paragraph p24= new Paragraph();
            p24.add(table21);
            
            // **27 Table contains subject P. T. and space for marks**
            PdfPTable table22 = new PdfPTable(3);
            table22.setWidthPercentage(100);
            PdfPCell t22_cell1 = new PdfPCell(new Phrase("P. T."));
            PdfPCell t22_cell2 = new PdfPCell(new Phrase(pt_s2));
            PdfPCell t22_cell3 = new PdfPCell(new Phrase(needtoimprovein_s2));
            t22_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t22_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t22_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t22_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t22_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t22_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table22.addCell(t22_cell1);
            table22.addCell(t22_cell2);
            table22.addCell(t22_cell3);
            Paragraph p25= new Paragraph();
            p25.add(table22);
            
            // **28 Table contains subject G.K / V. Edu. and space for marks**
            PdfPTable table23 = new PdfPTable(3);
            table23.setWidthPercentage(100);
            PdfPCell t23_cell1 = new PdfPCell(new Phrase("G.K / V. Edu."));
            PdfPCell t23_cell2 = new PdfPCell(new Phrase(gkVed_s2));
            PdfPCell t23_cell3 = new PdfPCell(new Phrase("   "));
            t23_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t23_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t23_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t23_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t23_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t23_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table23.addCell(t23_cell1);
            table23.addCell(t23_cell2);
            table23.addCell(t23_cell3);
            Paragraph p26= new Paragraph();
            p26.add(table23);
            
            // **29 Table contains subject Music and space for marks**
            PdfPTable table24 = new PdfPTable(3);
            table24.setWidthPercentage(100);
            PdfPCell t24_cell1 = new PdfPCell(new Phrase("Music"));
            PdfPCell t24_cell2 = new PdfPCell(new Phrase(music_s2));
            PdfPCell t24_cell3 = new PdfPCell(new Phrase("   "));
            t24_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t24_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t24_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t24_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t24_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t24_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table24.addCell(t24_cell1);
            table24.addCell(t24_cell2);
            table24.addCell(t24_cell3);
            Paragraph p27= new Paragraph();
            p27.add(table24);
            
            // **47 Spacer**
            Paragraph p46 = new Paragraph();
            addEmptyLine(p46, 1);
            
            // **45 Table contains passed and promoted to line**
            PdfPTable table39 = new PdfPTable(2);
            table39.setWidthPercentage(100);
            PdfPCell t39_cell1 = new PdfPCell(new Phrase("Passed and promoted to: "));
            PdfPCell t39_cell2 = new PdfPCell(new Phrase("   "));
            t39_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t39_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t39_cell1.setBorder(Rectangle.NO_BORDER);
            t39_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t39_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t39_cell2.setBorder(Rectangle.NO_BORDER);
            table39.addCell(t39_cell1);
            table39.addCell(t39_cell2);
            Paragraph p42= new Paragraph();
            p42.add(table39);
            
            // **47 Spacer**
            Paragraph p44 = new Paragraph();
            addEmptyLine(p44, 2);
            
            // **46 Table contains signatures** Table 40, 41, 42 are unused.
            PdfPTable table43 = new PdfPTable(3);
            table43.setWidthPercentage(100);
            PdfPCell t43_cell1 = new PdfPCell(new Phrase("Teacher's Sign"));
            PdfPCell t43_cell2 = new PdfPCell(new Phrase("Principal's Sign"));
            PdfPCell t43_cell3 = new PdfPCell(new Phrase("Parent's Sign"));
            t43_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t43_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t43_cell1.setBorder(Rectangle.NO_BORDER);
            t43_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t43_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t43_cell2.setBorder(Rectangle.NO_BORDER);
            t43_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t43_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            t43_cell3.setBorder(Rectangle.NO_BORDER);
            table43.addCell(t43_cell1);
            table43.addCell(t43_cell2);
            table43.addCell(t43_cell3);
            Paragraph p43= new Paragraph();
            p43.add(table43);
            
            // **30 Adds New Page
            
            // **31 Table contains title of new page - Second Semester**
            PdfPTable table25 = new PdfPTable(1);
            table25.setWidthPercentage(100);
            PdfPCell t25_cell1 = new PdfPCell(new Phrase("Second Semester"));
            t25_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t25_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table25.addCell(t25_cell1);
            Paragraph p28= new Paragraph();
            p28.add(table25);
            
            // **32 Table contains coulmn names**
            PdfPTable table26 = new PdfPTable(3);
            table26.setWidthPercentage(100);
            PdfPCell t26_cell1 = new PdfPCell(new Phrase("Subject"));
            PdfPCell t26_cell2 = new PdfPCell(new Phrase("Marks"));
            PdfPCell t26_cell3 = new PdfPCell(new Phrase("Descriptive Detail"));
            t26_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t26_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t26_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t26_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t26_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t26_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table26.addCell(t26_cell1);
            table26.addCell(t26_cell2);
            table26.addCell(t26_cell3);
            Paragraph p29= new Paragraph();
            p29.add(table26);
            
            // **33 Table contains subject English and space for marks**
            PdfPTable table27 = new PdfPTable(3);
            table27.setWidthPercentage(100);
            PdfPCell t27_cell1 = new PdfPCell(new Phrase("English"));
            PdfPCell t27_cell2 = new PdfPCell(new Phrase(english));
            PdfPCell t27_cell3 = new PdfPCell(new Phrase("Specific Progress"));
            t27_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t27_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t27_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t27_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t27_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t27_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table27.addCell(t27_cell1);
            table27.addCell(t27_cell2);
            table27.addCell(t27_cell3);
            Paragraph p30= new Paragraph();
            p30.add(table27);
            
            // **34 Table contains subject Marathi and space for marks**
            PdfPTable table28 = new PdfPTable(3);
            table28.setWidthPercentage(100);
            PdfPCell t28_cell1 = new PdfPCell(new Phrase("Marathi"));
            PdfPCell t28_cell2 = new PdfPCell(new Phrase(marathi));
            PdfPCell t28_cell3 = new PdfPCell(new Phrase(specificProg));
            t28_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t28_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t28_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t28_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t28_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t28_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table28.addCell(t28_cell1);
            table28.addCell(t28_cell2);
            table28.addCell(t28_cell3);
            Paragraph p31= new Paragraph();
            p31.add(table28);
            
            // **35 Table contains subject Hindi and space for marks**
            PdfPTable table29 = new PdfPTable(3);
            table29.setWidthPercentage(100);
            PdfPCell t29_cell1 = new PdfPCell(new Phrase("Hindi"));
            PdfPCell t29_cell2 = new PdfPCell(new Phrase(hindi));
            PdfPCell t29_cell3 = new PdfPCell(new Phrase("   "));
            t29_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t29_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t29_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t29_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t29_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t29_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table29.addCell(t29_cell1);
            table29.addCell(t29_cell2);
            table29.addCell(t29_cell3);
            Paragraph p32= new Paragraph();
            p32.add(table29);
            
            // **36 Table contains subject Maths and space for marks**
            PdfPTable table30 = new PdfPTable(3);
            table30.setWidthPercentage(100);
            PdfPCell t30_cell1 = new PdfPCell(new Phrase("Maths"));
            PdfPCell t30_cell2 = new PdfPCell(new Phrase(maths));
            PdfPCell t30_cell3 = new PdfPCell(new Phrase("   "));
            t30_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t30_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t30_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t30_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t30_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t30_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table30.addCell(t30_cell1);
            table30.addCell(t30_cell2);
            table30.addCell(t30_cell3);
            Paragraph p33= new Paragraph();
            p33.add(table30);
            
            // **37 Table contains subject G. Science and space for marks**
            PdfPTable table31 = new PdfPTable(3);
            table31.setWidthPercentage(100);
            PdfPCell t31_cell1 = new PdfPCell(new Phrase("G. Science"));
            PdfPCell t31_cell2 = new PdfPCell(new Phrase(gscience));
            PdfPCell t31_cell3 = new PdfPCell(new Phrase("Liking / Hobby"));
            t31_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t31_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t31_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t31_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t31_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t31_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table31.addCell(t31_cell1);
            table31.addCell(t31_cell2);
            table31.addCell(t31_cell3);
            Paragraph p34= new Paragraph();
            p34.add(table31);
            
            // **38 Table contains subject EVS and space for marks**
            PdfPTable table32 = new PdfPTable(3);
            table32.setWidthPercentage(100);
            PdfPCell t32_cell1 = new PdfPCell(new Phrase("EVS"));
            PdfPCell t32_cell2 = new PdfPCell(new Phrase(evs));
            PdfPCell t32_cell3 = new PdfPCell(new Phrase(likinghobby));
            t32_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t32_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t32_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t32_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t32_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t32_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table32.addCell(t32_cell1);
            table32.addCell(t32_cell2);
            table32.addCell(t32_cell3);
            Paragraph p35= new Paragraph();
            p35.add(table32);
            
            // **39 Table contains subject History / Geography and space for marks**
            PdfPTable table33 = new PdfPTable(3);
            table33.setWidthPercentage(100);
            PdfPCell t33_cell1 = new PdfPCell(new Phrase("History / Geography"));
            PdfPCell t33_cell2 = new PdfPCell(new Phrase(hstory));
            PdfPCell t33_cell3 = new PdfPCell(new Phrase("   "));
            t33_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t33_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t33_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t33_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t33_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t33_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table33.addCell(t33_cell1);
            table33.addCell(t33_cell2);
            table33.addCell(t33_cell3);
            Paragraph p36= new Paragraph();
            p36.add(table33);
            
            // **40 Table contains subject Art / Craft and space for marks**
            PdfPTable table34 = new PdfPTable(3);
            table34.setWidthPercentage(100);
            PdfPCell t34_cell1 = new PdfPCell(new Phrase("Art / Craft"));
            PdfPCell t34_cell2 = new PdfPCell(new Phrase(arts));
            PdfPCell t34_cell3 = new PdfPCell(new Phrase("   "));
            t34_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t34_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t34_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t34_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t34_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t34_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table34.addCell(t34_cell1);
            table34.addCell(t34_cell2);
            table34.addCell(t34_cell3);
            Paragraph p37= new Paragraph();
            p37.add(table34);
            
            // **41 Table contains subject Computer and space for marks**
            PdfPTable table35 = new PdfPTable(3);
            table35.setWidthPercentage(100);
            PdfPCell t35_cell1 = new PdfPCell(new Phrase("Computer"));
            PdfPCell t35_cell2 = new PdfPCell(new Phrase(computer));
            PdfPCell t35_cell3 = new PdfPCell(new Phrase("Need to Improve In"));
            t35_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t35_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t35_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t35_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t35_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t35_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table35.addCell(t35_cell1);
            table35.addCell(t35_cell2);
            table35.addCell(t35_cell3);
            Paragraph p38= new Paragraph();
            p38.add(table35);
            
            // **42 Table contains subject P. T. and space for marks**
            PdfPTable table36 = new PdfPTable(3);
            table36.setWidthPercentage(100);
            PdfPCell t36_cell1 = new PdfPCell(new Phrase("P. T."));
            PdfPCell t36_cell2 = new PdfPCell(new Phrase(pt));
            PdfPCell t36_cell3 = new PdfPCell(new Phrase(needtoimprove));
            t36_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t36_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t36_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t36_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t36_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t36_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table36.addCell(t36_cell1);
            table36.addCell(t36_cell2);
            table36.addCell(t36_cell3);
            Paragraph p39= new Paragraph();
            p39.add(table36);
            
            // **43 Table contains subject G.K / V. Edu. and space for marks**
            PdfPTable table37 = new PdfPTable(3);
            table37.setWidthPercentage(100);
            PdfPCell t37_cell1 = new PdfPCell(new Phrase("G.K / V. Edu."));
            PdfPCell t37_cell2 = new PdfPCell(new Phrase(gk));
            PdfPCell t37_cell3 = new PdfPCell(new Phrase("   "));
            t37_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t37_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t37_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t37_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t37_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t37_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table37.addCell(t37_cell1);
            table37.addCell(t37_cell2);
            table37.addCell(t37_cell3);
            Paragraph p40= new Paragraph();
            p40.add(table37);
            
            // **44 Table contains subject Music and space for marks**
            PdfPTable table38 = new PdfPTable(3);
            table38.setWidthPercentage(100);
            PdfPCell t38_cell1 = new PdfPCell(new Phrase("Music"));
            PdfPCell t38_cell2 = new PdfPCell(new Phrase(music));
            PdfPCell t38_cell3 = new PdfPCell(new Phrase("   "));
            t38_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t38_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t38_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t38_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t38_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t38_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table38.addCell(t38_cell1);
            table38.addCell(t38_cell2);
            table38.addCell(t38_cell3);
            Paragraph p41= new Paragraph();
            p41.add(table38);
            
            // **59 Spacer**
            Paragraph p59 = new Paragraph();
            addEmptyLine(p59, 1);
            
            // **60 Table contains passed and promoted to line**
            PdfPTable table59 = new PdfPTable(2);
            table59.setWidthPercentage(100);
            PdfPCell t59_cell1 = new PdfPCell(new Phrase("Passed and promoted to: "));
            PdfPCell t59_cell2 = new PdfPCell(new Phrase(passedPromoted));
            t59_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t59_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t59_cell1.setBorder(Rectangle.NO_BORDER);
            t59_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t59_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t59_cell2.setBorder(Rectangle.NO_BORDER);
            table59.addCell(t59_cell1);
            table59.addCell(t59_cell2);
            Paragraph p60= new Paragraph();
            p60.add(table59);
            
            // **61 Table contains Attendance compulsory line**
            PdfPTable table61 = new PdfPTable(1);
            table61.setWidthPercentage(100);
            PdfPCell t61_cell1 = new PdfPCell(new Phrase("Attendance on Reopening day is compulsory"));
            t61_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t61_cell1.setHorizontalAlignment(Element.ALIGN_LEFT);
            t61_cell1.setBorder(Rectangle.NO_BORDER);
            table61.addCell(t61_cell1);
            Paragraph p61= new Paragraph();
            p61.add(table61);
            
            // **62 Spacer**
            Paragraph p62 = new Paragraph();
            addEmptyLine(p62, 2);
            
            // **63 Table contains signatures**
            PdfPTable table63 = new PdfPTable(3);
            table63.setWidthPercentage(100);
            PdfPCell t63_cell1 = new PdfPCell(new Phrase("Teacher's Sign"));
            PdfPCell t63_cell2 = new PdfPCell(new Phrase("Principal's Sign"));
            PdfPCell t63_cell3 = new PdfPCell(new Phrase("Parent's Sign"));
            t63_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t63_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t63_cell1.setBorder(Rectangle.NO_BORDER);
            t63_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t63_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t63_cell2.setBorder(Rectangle.NO_BORDER);
            t63_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t63_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            t63_cell3.setBorder(Rectangle.NO_BORDER);
            table63.addCell(t63_cell1);
            table63.addCell(t63_cell2);
            table63.addCell(t63_cell3);
            Paragraph p63= new Paragraph();
            p63.add(table63);
            
            // **49 Adds New Page
            
            // **50 Table contains months**
            PdfPTable table50 = new PdfPTable(13);
            table50.setWidthPercentage(100);
            PdfPCell t50_cell1 = new PdfPCell(new Phrase("Month"));
            PdfPCell t50_cell2 = new PdfPCell(new Phrase("June"));
            PdfPCell t50_cell3 = new PdfPCell(new Phrase("July"));
            PdfPCell t50_cell4 = new PdfPCell(new Phrase("Aug"));
            PdfPCell t50_cell5 = new PdfPCell(new Phrase("Sep"));
            PdfPCell t50_cell6 = new PdfPCell(new Phrase("Oct"));
            PdfPCell t50_cell7 = new PdfPCell(new Phrase("Nov"));
            PdfPCell t50_cell8 = new PdfPCell(new Phrase("Dec"));
            PdfPCell t50_cell9 = new PdfPCell(new Phrase("Jan"));
            PdfPCell t50_cell10 = new PdfPCell(new Phrase("Feb"));
            PdfPCell t50_cell11 = new PdfPCell(new Phrase("Mar"));
            PdfPCell t50_cell12 = new PdfPCell(new Phrase("Apr"));
            PdfPCell t50_cell13 = new PdfPCell(new Phrase("May"));
            t50_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell4.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell5.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell6.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell7.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell8.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell9.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell10.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell11.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell12.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
            t50_cell13.setVerticalAlignment(Element.ALIGN_CENTER);
            t50_cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
            table50.addCell(t50_cell1);
            table50.addCell(t50_cell2);
            table50.addCell(t50_cell3);
            table50.addCell(t50_cell4);
            table50.addCell(t50_cell5);
            table50.addCell(t50_cell6);
            table50.addCell(t50_cell7);
            table50.addCell(t50_cell8);
            table50.addCell(t50_cell9);
            table50.addCell(t50_cell10);
            table50.addCell(t50_cell11);
            table50.addCell(t50_cell12);
            table50.addCell(t50_cell13);
            Paragraph p50= new Paragraph();
            p50.add(table50);
            
            // **51 Table contains Working Days**
            PdfPTable table51 = new PdfPTable(13);
            table51.setWidthPercentage(100);
            PdfPCell t51_cell1 = new PdfPCell(new Phrase("Working Days"));
            PdfPCell t51_cell2 = new PdfPCell(new Phrase(junewd_s2));
            PdfPCell t51_cell3 = new PdfPCell(new Phrase(julywd_s2));
            PdfPCell t51_cell4 = new PdfPCell(new Phrase(augwd_s2));
            PdfPCell t51_cell5 = new PdfPCell(new Phrase(sepwd_s2));
            PdfPCell t51_cell6 = new PdfPCell(new Phrase(octwd_s2));
            PdfPCell t51_cell7 = new PdfPCell(new Phrase(novwd_s2));
            PdfPCell t51_cell8 = new PdfPCell(new Phrase(decwd));
            PdfPCell t51_cell9 = new PdfPCell(new Phrase(janwd));
            PdfPCell t51_cell10 = new PdfPCell(new Phrase(febwd));
            PdfPCell t51_cell11 = new PdfPCell(new Phrase(marwd));
            PdfPCell t51_cell12 = new PdfPCell(new Phrase(aprwd));
            PdfPCell t51_cell13 = new PdfPCell(new Phrase(maywd));
            t51_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell4.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell5.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell6.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell7.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell8.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell9.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell10.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell11.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell12.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
            t51_cell13.setVerticalAlignment(Element.ALIGN_CENTER);
            t51_cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
            table51.addCell(t51_cell1);
            table51.addCell(t51_cell2);
            table51.addCell(t51_cell3);
            table51.addCell(t51_cell4);
            table51.addCell(t51_cell5);
            table51.addCell(t51_cell6);
            table51.addCell(t51_cell7);
            table51.addCell(t51_cell8);
            table51.addCell(t51_cell9);
            table51.addCell(t51_cell10);
            table51.addCell(t51_cell11);
            table51.addCell(t51_cell12);
            table51.addCell(t51_cell13);
            Paragraph p51= new Paragraph();
            p51.add(table51);
            
            // **52 Table contains Present Days**
            PdfPTable table52 = new PdfPTable(13);
            table52.setWidthPercentage(100);
            PdfPCell t52_cell1 = new PdfPCell(new Phrase("Present Days"));
            PdfPCell t52_cell2 = new PdfPCell(new Phrase(junepd_s2));
            PdfPCell t52_cell3 = new PdfPCell(new Phrase(julypd_s2));
            PdfPCell t52_cell4 = new PdfPCell(new Phrase(augpd_s2));
            PdfPCell t52_cell5 = new PdfPCell(new Phrase(seppd_s2));
            PdfPCell t52_cell6 = new PdfPCell(new Phrase(octpd_s2));
            PdfPCell t52_cell7 = new PdfPCell(new Phrase(novpd_s2));
            PdfPCell t52_cell8 = new PdfPCell(new Phrase(decpd));
            PdfPCell t52_cell9 = new PdfPCell(new Phrase(janpd));
            PdfPCell t52_cell10 = new PdfPCell(new Phrase(febpd));
            PdfPCell t52_cell11 = new PdfPCell(new Phrase(marpd));
            PdfPCell t52_cell12 = new PdfPCell(new Phrase(aprpd));
            PdfPCell t52_cell13 = new PdfPCell(new Phrase(maypd));
            t52_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell4.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell5.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell6.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell7.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell8.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell9.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell10.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell11.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell11.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell12.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell12.setHorizontalAlignment(Element.ALIGN_CENTER);
            t52_cell13.setVerticalAlignment(Element.ALIGN_CENTER);
            t52_cell13.setHorizontalAlignment(Element.ALIGN_CENTER);
            table52.addCell(t52_cell1);
            table52.addCell(t52_cell2);
            table52.addCell(t52_cell3);
            table52.addCell(t52_cell4);
            table52.addCell(t52_cell5);
            table52.addCell(t52_cell6);
            table52.addCell(t52_cell7);
            table52.addCell(t52_cell8);
            table52.addCell(t52_cell9);
            table52.addCell(t52_cell10);
            table52.addCell(t52_cell11);
            table52.addCell(t52_cell12);
            table52.addCell(t52_cell13);
            Paragraph p52= new Paragraph();
            p52.add(table52);
           
            // **53 Table contains Class Teacher's Sign**
            PdfPTable table53 = new PdfPTable(3);
            table53.setWidthPercentage(100);
            PdfPCell t53_cell1 = new PdfPCell(new Phrase("Class Teacher's Sign"));
            PdfPCell t53_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t53_cell3 = new PdfPCell(new Phrase("   "));
            t53_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t53_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t53_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t53_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t53_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t53_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table53.addCell(t53_cell1);
            table53.addCell(t53_cell2);
            table53.addCell(t53_cell3);
            Paragraph p53= new Paragraph();
            p53.add(table53);
            
            // **54 Table contains Class Teacher's Sign**
            PdfPTable table54 = new PdfPTable(3);
            table54.setWidthPercentage(100);
            PdfPCell t54_cell1 = new PdfPCell(new Phrase("Parent's Sign"));
            PdfPCell t54_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t54_cell3 = new PdfPCell(new Phrase("   "));
            t54_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t54_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t54_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t54_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t54_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t54_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table54.addCell(t54_cell1);
            table54.addCell(t54_cell2);
            table54.addCell(t54_cell3);
            Paragraph p54= new Paragraph();
            p54.add(table54);
            
            // **55 Table contains Principal's Sign**
            PdfPTable table55 = new PdfPTable(3);
            table55.setWidthPercentage(100);
            PdfPCell t55_cell1 = new PdfPCell(new Phrase("Principal's Sign"));
            PdfPCell t55_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t55_cell3 = new PdfPCell(new Phrase("   "));
            t55_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t55_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t55_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t55_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t55_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t55_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table55.addCell(t55_cell1);
            table55.addCell(t55_cell2);
            table55.addCell(t55_cell3);
            Paragraph p55= new Paragraph();
            p55.add(table55);
            
            // **56 Spacer**
            Paragraph p56 = new Paragraph();
            addEmptyLine(p56, 3);
            
            // **57 Table contains Assessment of the Marks**
            PdfPTable table57 = new PdfPTable(10);
            table57.setWidthPercentage(100);
            PdfPCell t57_cell1 = new PdfPCell(new Phrase("Assessment of the Marks"));
            PdfPCell t57_cell2 = new PdfPCell(new Phrase("91% to 100%"));
            PdfPCell t57_cell3 = new PdfPCell(new Phrase("81% to 90%"));
            PdfPCell t57_cell4 = new PdfPCell(new Phrase("71% to 80%"));
            PdfPCell t57_cell5 = new PdfPCell(new Phrase("61% to 70%"));
            PdfPCell t57_cell6 = new PdfPCell(new Phrase("51% to 60%"));
            PdfPCell t57_cell7 = new PdfPCell(new Phrase("41% to 50%"));
            PdfPCell t57_cell8 = new PdfPCell(new Phrase("31% to 40%"));
            PdfPCell t57_cell9 = new PdfPCell(new Phrase("21% to 30%"));
            PdfPCell t57_cell10 = new PdfPCell(new Phrase("Less then 20%"));
            t57_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell4.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell5.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell6.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell7.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell8.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell9.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
            t57_cell10.setVerticalAlignment(Element.ALIGN_CENTER);
            t57_cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
            table57.addCell(t57_cell1);
            table57.addCell(t57_cell2);
            table57.addCell(t57_cell3);
            table57.addCell(t57_cell4);
            table57.addCell(t57_cell5);
            table57.addCell(t57_cell6);
            table57.addCell(t57_cell7);
            table57.addCell(t57_cell8);
            table57.addCell(t57_cell9);
            table57.addCell(t57_cell10);
            Paragraph p57= new Paragraph();
            p57.add(table57);
            
            // **58 Table contains Grade**
            PdfPTable table58 = new PdfPTable(10);
            table58.setWidthPercentage(100);
            PdfPCell t58_cell1 = new PdfPCell(new Phrase("Grade"));
            PdfPCell t58_cell2 = new PdfPCell(new Phrase("A-1"));
            PdfPCell t58_cell3 = new PdfPCell(new Phrase("A-2"));
            PdfPCell t58_cell4 = new PdfPCell(new Phrase("B-1"));
            PdfPCell t58_cell5 = new PdfPCell(new Phrase("B-2"));
            PdfPCell t58_cell6 = new PdfPCell(new Phrase("C-1"));
            PdfPCell t58_cell7 = new PdfPCell(new Phrase("C-2"));
            PdfPCell t58_cell8 = new PdfPCell(new Phrase("D"));
            PdfPCell t58_cell9 = new PdfPCell(new Phrase("E-1"));
            PdfPCell t58_cell10 = new PdfPCell(new Phrase("E-2"));
            t58_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell4.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell5.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell6.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell7.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell7.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell8.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell8.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell9.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell9.setHorizontalAlignment(Element.ALIGN_CENTER);
            t58_cell10.setVerticalAlignment(Element.ALIGN_CENTER);
            t58_cell10.setHorizontalAlignment(Element.ALIGN_CENTER);
            table58.addCell(t58_cell1);
            table58.addCell(t58_cell2);
            table58.addCell(t58_cell3);
            table58.addCell(t58_cell4);
            table58.addCell(t58_cell5);
            table58.addCell(t58_cell6);
            table58.addCell(t58_cell7);
            table58.addCell(t58_cell8);
            table58.addCell(t58_cell9);
            table58.addCell(t58_cell10);
            Paragraph p58= new Paragraph();
            p58.add(table58);
            
            // Makes a new document and opens it
            Document document = new Document(PageSize.A5);
            PdfWriter.getInstance(document,file);
            document.open();
            
            // Add stuff to the document
            document.add(p1);           // **1 Holy Cross Header Image**
            document.add(p3);           // **2 Spacer**
            document.add(p2);           // **3 This table contains the main Title**
            document.add(p71);           // **71 Spacer**
            document.add(p70);           // **70 Student's Photo**
            document.add(p5);           // **4 Spacer**
            //  document.add();             // **5 Student's Photo**
            document.add(p4);           // **6 Table contains first line from Report card**
            document.add(p6);           // **7 Table contains secound line from Report card**
            document.add(p7);           // **8 Table contains third line from Report card**
            document.add(p8);           // **9 Table contains fourth line from Report card**
            document.add(p9);           // **10 Table contains fifth line from Report card**
            document.add(p10);          // **11 Table contains sixth line from Report card**
            document.add(p11);          // **12 Table contains seventh line from Report card**
            document.add(p12);          // **13 Table contains eighth line from Report card**
            document.add(p13);          // **14 Table contains ninth line from Report card**
            
            document.newPage();         // **15 Adds New Page
            document.add(p14);          // **16 Table contains title of new page - First Semester**
            document.add(p15);          // **17 Table contains coulmn names**
            document.add(p16);          // **18 Table contains subject English and space for marks**
            document.add(p17);          // **19 Table contains subject Marathi and space for marks**
            document.add(p18);          // **20 Table contains subject Hindi and space for marks**
            document.add(p19);          // **21 Table contains subject Maths and space for marks**
            document.add(p20);          // **22 Table contains subject G. Science and space for marks**
            document.add(p21);          // **23 Table contains subject EVS and space for marks**
            document.add(p22);          // **24 Table contains subject His/Geo and space for marks**
            document.add(p23);          // **25 Table contains subject Art / Craft and space for marks**
            document.add(p24);          // **26 Table contains subject Computer and space for marks**
            document.add(p25);          // **27 Table contains subject PT Science and space for marks**
            document.add(p26);          // **28 Table contains subject GK Science and space for marks**
            document.add(p27);          // **29 Table contains subject Music and space for marks**
            document.add(p46);          // **48 Spacer**
            document.add(p42);          // **45 Table contains passed and promoted to line**
            document.add(p44);          // **47 Spacer**
            document.add(p43);          // **46 Signatures 
            
            document.newPage();         // **30 Adds New Page
            document.add(p28);          // **31 Table contains title of new page - Second Semester**
            document.add(p29);          // **32 Table contains coulmn names**
            document.add(p30);          // **33 Table contains subject English and space for marks**
            document.add(p31);          // **34 Table contains subject Marathi and space for marks**
            document.add(p32);          // **35 Table contains subject Hindi and space for marks**
            document.add(p33);          // **36 Table contains subject Maths and space for marks**
            document.add(p34);          // **37 Table contains subject G. Science and space for marks**
            document.add(p35);          // **38 Table contains subject EVS and space for marks**
            document.add(p36);          // **39 Table contains subject His/Geo and space for marks**
            document.add(p37);          // **40 Table contains subject Art / Craft and space for marks**
            document.add(p38);          // **41 Table contains subject Computer and space for marks**
            document.add(p39);          // **42 Table contains subject PT Science and space for marks**
            document.add(p40);          // **43 Table contains subject GK Science and space for marks**
            document.add(p41);          // **44 Table contains subject Music and space for marks**
            document.add(p59);          // **59 Spacer**
            document.add(p60);          // **60 Table contains passed and promoted to line**
            document.add(p61);          // **61 Table contains Attendance compulsory line**
            document.add(p62);          // **62 Spacer**
            document.add(p63);          // **63 Table contains signatures**    
            
            document.newPage();         // **49 Adds New Page
            document.add(p50);          // **50 Table contains months**
            document.add(p51);          // **51 Table contains Working Days**
            document.add(p52);          // **52 Table contains Present Days**
            document.add(p53);          // **53 Table contains Class Teacher's Sign**
            document.add(p54);          // **54 Table contains Parent's Sign**
            document.add(p55);          // **55 Table contains Principal's Sign**
            document.add(p56);          // **56 Spacer**
            document.add(p57);          // **57 Table contains Assessment of the Marks**
            document.add(p58);          // **58 Table contains Grade**
            
            // Closes the document
            document.close();
            file.close();
            
            //printProgressReport_JR_FirstSem();
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
    }
//</editor-fold>
        
    //Method which prints Senior Semester 1st Marksheet
    //<editor-fold defaultstate="collapsed" desc="PPR Senior Sem 1">
    public void printProgressReportSenior_Sem1(int std_id, String gr_no, String report_type, String name, String roll_no, String Stand, String std_div,
            String fname, String focc, String mname, String mocc, String mtongue, String medium, String dob, String age, String phone,
            String email, String prHno, String prBldgNo, String prStrName, String prCity, String prDistrict, String prState, String semester)
    {
        
        String imagePath = "D:\\Workspace_Netbeans\\DignitySMS_1\\images\\header.jpg";
        
        Image image = null;
        try
        {
            // Make stuff for the document
            
            // Makes the Image
            OutputStream file = new FileOutputStream(new File("C:\\Users\\admin\\Desktop\\Progressreport\\Report_"+std_id+"_"+gr_no+"_"+semester+"_"+report_type+".pdf"));
            image = Image.getInstance(imagePath);
            //image.setAlignment(Element.ALIGN_CENTER);
            //image.setAbsolutePosition(50f, 700f);
            //image.scaleAbsolute(500f, 100f);
            
            // **1 Holy Cross Header Image**
            PdfPTable table = new PdfPTable(1);
            table.setWidthPercentage(70);
            //table.setWidths(new float[]{2.6f,1.6f});
            table.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(image);
            table.setHorizontalAlignment(50);
            Paragraph p1= new Paragraph();
            p1.add(table);
            
            // **2 Spacer**
            Paragraph p3 = new Paragraph();
            addEmptyLine(p3, 1);
            
            // **3 This table contains the main Title**
            PdfPTable table1 = new PdfPTable(1);
            table1.setWidthPercentage(50);
            //table.setWidths(new float[]{2.6f,1.6f});
            table1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table1.setHorizontalAlignment(50);
            PdfPCell cell = new PdfPCell(new Phrase("CONTINUOS CUMULATIVE EVALUATION PROGRESS REPORT 2016-2017"));
            cell.setVerticalAlignment(Element.ALIGN_CENTER);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table1.addCell(cell);
            Paragraph p2= new Paragraph();
            p2.add(table1);
            
            // **4 Spacer**
            Paragraph p5 = new Paragraph();
            addEmptyLine(p5, 3);
            
            // **5 Student's Photo**
            
            // **6 Table contains first line from Report card**
            PdfPTable table2 = new PdfPTable(2);
            table2.setWidthPercentage(70);
            PdfPCell cellOne = new PdfPCell(new Phrase("Name: "+name+""));
            PdfPCell cellTwo = new PdfPCell(new Phrase("Roll No: "+roll_no+""));
            cellOne.setBorder(Rectangle.NO_BORDER);
            cellTwo.setBorder(Rectangle.NO_BORDER);
            table2.addCell(cellOne);
            table2.addCell(cellTwo);
            Paragraph p4= new Paragraph();
            p4.add(table2);
            
            // **7 Table contains secound line from Report card**
            PdfPTable table3 = new PdfPTable(2);
            table3.setWidthPercentage(70);
            PdfPCell t3_cell1 = new PdfPCell(new Phrase("STD: "+Stand+""));
            PdfPCell t3_cell2 = new PdfPCell(new Phrase("Division: "+std_div+""));
            //    PdfPCell t3_cell3 = new PdfPCell(new Phrase("G.R. No: "+gr_no+""));
            t3_cell1.setBorder(Rectangle.NO_BORDER);
            t3_cell2.setBorder(Rectangle.NO_BORDER);
            //    t3_cell3.setBorder(Rectangle.NO_BORDER);
            table3.addCell(t3_cell1);
            table3.addCell(t3_cell2);
            //    table3.addCell(t3_cell3);
            Paragraph p6= new Paragraph();
            p6.add(table3);
            
            // **8 Table contains third line from Report card**
            PdfPTable table4 = new PdfPTable(2);
            table4.setWidthPercentage(70);
            PdfPCell t4_cell1 = new PdfPCell(new Phrase("Father's Name: "+fname+""));
            PdfPCell t4_cell2 = new PdfPCell(new Phrase("Profession: "+focc+""));
            t4_cell1.setBorder(Rectangle.NO_BORDER);
            t4_cell2.setBorder(Rectangle.NO_BORDER);
            table4.addCell(t4_cell1);
            table4.addCell(t4_cell2);
            Paragraph p7= new Paragraph();
            p7.add(table4);
            
            // **9 Table contains fourth line from Report card**
            PdfPTable table5 = new PdfPTable(2);
            table5.setWidthPercentage(70);
            PdfPCell t5_cell1 = new PdfPCell(new Phrase("Mother's Name: "+mname+""));
            PdfPCell t5_cell2 = new PdfPCell(new Phrase("Profession: "+mocc+""));
            t5_cell1.setBorder(Rectangle.NO_BORDER);
            t5_cell2.setBorder(Rectangle.NO_BORDER);
            table5.addCell(t5_cell1);
            table5.addCell(t5_cell2);
            Paragraph p8= new Paragraph();
            p8.add(table5);
            
            // **10 Table contains fifth line from Report card**
            PdfPTable table6 = new PdfPTable(2);
            table6.setWidthPercentage(70);
            PdfPCell t6_cell1 = new PdfPCell(new Phrase("Mother Tongue: "+mtongue+""));
            PdfPCell t6_cell2 = new PdfPCell(new Phrase("Medium: "+medium+""));
            t6_cell1.setBorder(Rectangle.NO_BORDER);
            t6_cell2.setBorder(Rectangle.NO_BORDER);
            table6.addCell(t6_cell1);
            table6.addCell(t6_cell2);
            Paragraph p9= new Paragraph();
            p9.add(table6);
            
            // **11 Table contains sixth line from Report card**
            PdfPTable table7 = new PdfPTable(2);
            table7.setWidthPercentage(70);
            PdfPCell t7_cell1 = new PdfPCell(new Phrase("Date of Birth: "+dob+""));
            PdfPCell t7_cell2 = new PdfPCell(new Phrase("Age: "+age+""));
            t7_cell1.setBorder(Rectangle.NO_BORDER);
            t7_cell2.setBorder(Rectangle.NO_BORDER);
            table7.addCell(t7_cell1);
            table7.addCell(t7_cell2);
            Paragraph p10= new Paragraph();
            p10.add(table7);
            
            // **12 Table contains seventh line from Report card**
            PdfPTable table8 = new PdfPTable(1);
            table8.setWidthPercentage(70);
            PdfPCell t8_cell1 = new PdfPCell(new Phrase("Address: "+prHno+" "+prBldgNo+" "+prStrName+""));
            t8_cell1.setBorder(Rectangle.NO_BORDER);
            table8.addCell(t8_cell1);
            Paragraph p11= new Paragraph();
            p11.add(table8);
            
            // **13 Table contains eighth line from Report card**
            PdfPTable table9 = new PdfPTable(1);
            table9.setWidthPercentage(70);
            PdfPCell t9_cell1 = new PdfPCell(new Phrase("Telephone No: "+phone+""));
            t9_cell1.setBorder(Rectangle.NO_BORDER);
            table9.addCell(t9_cell1);
            Paragraph p12= new Paragraph();
            p12.add(table9);
            
            // **14 Table contains ninth line from Report card**
            PdfPTable table10 = new PdfPTable(1);
            table10.setWidthPercentage(70);
            PdfPCell t10_cell1 = new PdfPCell(new Phrase("Email Id: "+email+""));
            t10_cell1.setBorder(Rectangle.NO_BORDER);
            table10.addCell(t10_cell1);
            Paragraph p13= new Paragraph();
            p13.add(table10);
            
            // **15 Adds New Page
            
            // **16 Table contains title of new page - First Semester**
            PdfPTable table11 = new PdfPTable(1);
            table11.setWidthPercentage(70);
            PdfPCell t11_cell1 = new PdfPCell(new Phrase("First Semester"));
            t11_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t11_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table11.addCell(t11_cell1);
            Paragraph p14= new Paragraph();
            p14.add(table11);
            
            // **17 Table contains coulmn names**
            PdfPTable table12 = new PdfPTable(3);
            table12.setWidthPercentage(70);
            PdfPCell t12_cell1 = new PdfPCell(new Phrase("Subject"));
            PdfPCell t12_cell2 = new PdfPCell(new Phrase("Marks"));
            PdfPCell t12_cell3 = new PdfPCell(new Phrase("Descriptive Detail"));
            t12_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t12_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t12_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t12_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t12_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t12_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table12.addCell(t12_cell1);
            table12.addCell(t12_cell2);
            table12.addCell(t12_cell3);
            Paragraph p15= new Paragraph();
            p15.add(table12);
            
            // **18 Table contains subject English and space for marks**
            PdfPTable table13 = new PdfPTable(3);
            table13.setWidthPercentage(70);
            PdfPCell t13_cell1 = new PdfPCell(new Phrase("English"));
            PdfPCell t13_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t13_cell3 = new PdfPCell(new Phrase("   "));
            t13_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t13_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t13_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t13_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t13_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t13_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table13.addCell(t13_cell1);
            table13.addCell(t13_cell2);
            table13.addCell(t13_cell3);
            Paragraph p16= new Paragraph();
            p16.add(table13);
            
            // **19 Table contains subject Marathi and space for marks**
            PdfPTable table14 = new PdfPTable(3);
            table14.setWidthPercentage(70);
            PdfPCell t14_cell1 = new PdfPCell(new Phrase("Marathi"));
            PdfPCell t14_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t14_cell3 = new PdfPCell(new Phrase("   "));
            t14_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t14_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t14_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t14_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t14_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t14_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table14.addCell(t14_cell1);
            table14.addCell(t14_cell2);
            table14.addCell(t14_cell3);
            Paragraph p17= new Paragraph();
            p17.add(table14);
            
            // **20 Table contains subject Hindi and space for marks**
            PdfPTable table15 = new PdfPTable(3);
            table15.setWidthPercentage(70);
            PdfPCell t15_cell1 = new PdfPCell(new Phrase("Hindi"));
            PdfPCell t15_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t15_cell3 = new PdfPCell(new Phrase("   "));
            t15_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t15_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t15_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t15_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t15_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t15_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table15.addCell(t15_cell1);
            table15.addCell(t15_cell2);
            table15.addCell(t15_cell3);
            Paragraph p18= new Paragraph();
            p18.add(table15);
            
            // **21 Table contains subject Maths and space for marks**
            PdfPTable table16 = new PdfPTable(3);
            table16.setWidthPercentage(70);
            PdfPCell t16_cell1 = new PdfPCell(new Phrase("Maths"));
            PdfPCell t16_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t16_cell3 = new PdfPCell(new Phrase("   "));
            t16_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t16_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t16_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t16_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t16_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t16_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table16.addCell(t16_cell1);
            table16.addCell(t16_cell2);
            table16.addCell(t16_cell3);
            Paragraph p19= new Paragraph();
            p19.add(table16);
            
            // **22 Table contains subject G. Science and space for marks**
            PdfPTable table17 = new PdfPTable(3);
            table17.setWidthPercentage(70);
            PdfPCell t17_cell1 = new PdfPCell(new Phrase("G. Science"));
            PdfPCell t17_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t17_cell3 = new PdfPCell(new Phrase("   "));
            t17_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t17_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t17_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t17_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t17_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t17_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table17.addCell(t17_cell1);
            table17.addCell(t17_cell2);
            table17.addCell(t17_cell3);
            Paragraph p20= new Paragraph();
            p20.add(table17);
            
            // **23 Table contains subject EVS and space for marks**
            PdfPTable table18 = new PdfPTable(3);
            table18.setWidthPercentage(70);
            PdfPCell t18_cell1 = new PdfPCell(new Phrase("EVS"));
            PdfPCell t18_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t18_cell3 = new PdfPCell(new Phrase("   "));
            t18_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t18_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t18_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t18_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t18_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t18_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table18.addCell(t18_cell1);
            table18.addCell(t18_cell2);
            table18.addCell(t18_cell3);
            Paragraph p21= new Paragraph();
            p21.add(table18);
            
            // **24 Table contains subject History / Geography and space for marks**
            PdfPTable table19 = new PdfPTable(3);
            table19.setWidthPercentage(70);
            PdfPCell t19_cell1 = new PdfPCell(new Phrase("History / Geography"));
            PdfPCell t19_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t19_cell3 = new PdfPCell(new Phrase("   "));
            t19_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t19_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t19_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t19_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t19_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t19_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table19.addCell(t19_cell1);
            table19.addCell(t19_cell2);
            table19.addCell(t19_cell3);
            Paragraph p22= new Paragraph();
            p22.add(table19);
            
            // **25 Table contains subject Art / Craft and space for marks**
            PdfPTable table20 = new PdfPTable(3);
            table20.setWidthPercentage(70);
            PdfPCell t20_cell1 = new PdfPCell(new Phrase("Art / Craft"));
            PdfPCell t20_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t20_cell3 = new PdfPCell(new Phrase("   "));
            t20_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t20_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t20_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t20_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t20_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t20_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table20.addCell(t20_cell1);
            table20.addCell(t20_cell2);
            table20.addCell(t20_cell3);
            Paragraph p23= new Paragraph();
            p23.add(table20);
            
            // **26 Table contains subject Computer and space for marks**
            PdfPTable table21 = new PdfPTable(3);
            table21.setWidthPercentage(70);
            PdfPCell t21_cell1 = new PdfPCell(new Phrase("Computer"));
            PdfPCell t21_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t21_cell3 = new PdfPCell(new Phrase("   "));
            t21_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t21_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t21_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t21_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t21_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t21_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table21.addCell(t21_cell1);
            table21.addCell(t21_cell2);
            table21.addCell(t21_cell3);
            Paragraph p24= new Paragraph();
            p24.add(table21);
            
            // **27 Table contains subject P. T. and space for marks**
            PdfPTable table22 = new PdfPTable(3);
            table22.setWidthPercentage(70);
            PdfPCell t22_cell1 = new PdfPCell(new Phrase("P. T."));
            PdfPCell t22_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t22_cell3 = new PdfPCell(new Phrase("   "));
            t22_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t22_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t22_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t22_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t22_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t22_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table22.addCell(t22_cell1);
            table22.addCell(t22_cell2);
            table22.addCell(t22_cell3);
            Paragraph p25= new Paragraph();
            p22.add(table22);
            
            // **28 Table contains subject G.K / V. Edu. and space for marks**
            PdfPTable table23 = new PdfPTable(3);
            table23.setWidthPercentage(70);
            PdfPCell t23_cell1 = new PdfPCell(new Phrase("G.K / V. Edu."));
            PdfPCell t23_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t23_cell3 = new PdfPCell(new Phrase("   "));
            t23_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t23_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t23_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t23_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t23_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t23_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table23.addCell(t23_cell1);
            table23.addCell(t23_cell2);
            table23.addCell(t23_cell3);
            Paragraph p26= new Paragraph();
            p26.add(table23);
            
            // **29 Table contains subject Music and space for marks**
            PdfPTable table24 = new PdfPTable(3);
            table24.setWidthPercentage(70);
            PdfPCell t24_cell1 = new PdfPCell(new Phrase("Music"));
            PdfPCell t24_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t24_cell3 = new PdfPCell(new Phrase("   "));
            t24_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t24_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t24_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t24_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t24_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t24_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table24.addCell(t24_cell1);
            table24.addCell(t24_cell2);
            table24.addCell(t24_cell3);
            Paragraph p27= new Paragraph();
            p27.add(table24);
            
            // **30 Adds New Page
            
            // **31 Table contains title of new page - Second Semester**
            PdfPTable table25 = new PdfPTable(1);
            table25.setWidthPercentage(70);
            PdfPCell t25_cell1 = new PdfPCell(new Phrase("Second Semester"));
            t25_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t25_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table25.addCell(t25_cell1);
            Paragraph p28= new Paragraph();
            p28.add(table25);
            
            // **32 Table contains coulmn names**
            PdfPTable table26 = new PdfPTable(3);
            table26.setWidthPercentage(70);
            PdfPCell t26_cell1 = new PdfPCell(new Phrase("Subject"));
            PdfPCell t26_cell2 = new PdfPCell(new Phrase("Marks"));
            PdfPCell t26_cell3 = new PdfPCell(new Phrase("Descriptive Detail"));
            t26_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t26_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t26_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t26_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t26_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t26_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table26.addCell(t26_cell1);
            table26.addCell(t26_cell2);
            table26.addCell(t26_cell3);
            Paragraph p29= new Paragraph();
            p29.add(table26);
            
            // **33 Table contains subject English and space for marks**
            PdfPTable table27 = new PdfPTable(3);
            table27.setWidthPercentage(70);
            PdfPCell t27_cell1 = new PdfPCell(new Phrase("English"));
            PdfPCell t27_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t27_cell3 = new PdfPCell(new Phrase("   "));
            t27_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t27_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t27_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t27_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t27_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t27_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table27.addCell(t27_cell1);
            table27.addCell(t27_cell2);
            table27.addCell(t27_cell3);
            Paragraph p30= new Paragraph();
            p30.add(table27);
            
            // **34 Table contains subject Marathi and space for marks**
            PdfPTable table28 = new PdfPTable(3);
            table28.setWidthPercentage(70);
            PdfPCell t28_cell1 = new PdfPCell(new Phrase("Marathi"));
            PdfPCell t28_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t28_cell3 = new PdfPCell(new Phrase("   "));
            t28_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t28_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t28_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t28_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t28_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t28_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table28.addCell(t28_cell1);
            table28.addCell(t28_cell2);
            table28.addCell(t28_cell3);
            Paragraph p31= new Paragraph();
            p31.add(table28);
            
            // **35 Table contains subject Hindi and space for marks**
            PdfPTable table29 = new PdfPTable(3);
            table29.setWidthPercentage(70);
            PdfPCell t29_cell1 = new PdfPCell(new Phrase("Hindi"));
            PdfPCell t29_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t29_cell3 = new PdfPCell(new Phrase("   "));
            t29_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t29_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t29_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t29_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t29_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t29_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table29.addCell(t29_cell1);
            table29.addCell(t29_cell2);
            table29.addCell(t29_cell3);
            Paragraph p32= new Paragraph();
            p32.add(table29);
            
            // **36 Table contains subject Maths and space for marks**
            PdfPTable table30 = new PdfPTable(3);
            table30.setWidthPercentage(70);
            PdfPCell t30_cell1 = new PdfPCell(new Phrase("Maths"));
            PdfPCell t30_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t30_cell3 = new PdfPCell(new Phrase("   "));
            t30_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t30_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t30_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t30_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t30_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t30_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table30.addCell(t30_cell1);
            table30.addCell(t30_cell2);
            table30.addCell(t30_cell3);
            Paragraph p33= new Paragraph();
            p33.add(table30);
            
            // **37 Table contains subject G. Science and space for marks**
            PdfPTable table31 = new PdfPTable(3);
            table31.setWidthPercentage(70);
            PdfPCell t31_cell1 = new PdfPCell(new Phrase("G. Science"));
            PdfPCell t31_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t31_cell3 = new PdfPCell(new Phrase("   "));
            t31_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t31_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t31_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t31_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t31_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t31_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table31.addCell(t31_cell1);
            table31.addCell(t31_cell2);
            table31.addCell(t31_cell3);
            Paragraph p34= new Paragraph();
            p34.add(table31);
            
            // **38 Table contains subject EVS and space for marks**
            PdfPTable table32 = new PdfPTable(3);
            table32.setWidthPercentage(70);
            PdfPCell t32_cell1 = new PdfPCell(new Phrase("EVS"));
            PdfPCell t32_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t32_cell3 = new PdfPCell(new Phrase("   "));
            t32_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t32_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t32_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t32_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t32_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t32_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table32.addCell(t32_cell1);
            table32.addCell(t32_cell2);
            table32.addCell(t32_cell3);
            Paragraph p35= new Paragraph();
            p35.add(table32);
            
            // **39 Table contains subject History / Geography and space for marks**
            PdfPTable table33 = new PdfPTable(3);
            table33.setWidthPercentage(70);
            PdfPCell t33_cell1 = new PdfPCell(new Phrase("History / Geography"));
            PdfPCell t33_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t33_cell3 = new PdfPCell(new Phrase("   "));
            t33_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t33_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t33_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t33_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t33_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t33_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table33.addCell(t33_cell1);
            table33.addCell(t33_cell2);
            table33.addCell(t33_cell3);
            Paragraph p36= new Paragraph();
            p36.add(table33);
            
            // **40 Table contains subject Art / Craft and space for marks**
            PdfPTable table34 = new PdfPTable(3);
            table34.setWidthPercentage(70);
            PdfPCell t34_cell1 = new PdfPCell(new Phrase("Art / Craft"));
            PdfPCell t34_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t34_cell3 = new PdfPCell(new Phrase("   "));
            t34_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t34_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t34_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t34_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t34_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t34_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table34.addCell(t34_cell1);
            table34.addCell(t34_cell2);
            table34.addCell(t34_cell3);
            Paragraph p37= new Paragraph();
            p37.add(table34);
            
            // **41 Table contains subject Computer and space for marks**
            PdfPTable table35 = new PdfPTable(3);
            table35.setWidthPercentage(70);
            PdfPCell t35_cell1 = new PdfPCell(new Phrase("Computer"));
            PdfPCell t35_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t35_cell3 = new PdfPCell(new Phrase("   "));
            t35_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t35_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t35_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t35_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t35_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t35_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table35.addCell(t35_cell1);
            table35.addCell(t35_cell2);
            table35.addCell(t35_cell3);
            Paragraph p38= new Paragraph();
            p38.add(table35);
            
            // **42 Table contains subject P. T. and space for marks**
            PdfPTable table36 = new PdfPTable(3);
            table36.setWidthPercentage(70);
            PdfPCell t36_cell1 = new PdfPCell(new Phrase("P. T."));
            PdfPCell t36_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t36_cell3 = new PdfPCell(new Phrase("   "));
            t36_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t36_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t36_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t36_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t36_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t36_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table36.addCell(t36_cell1);
            table36.addCell(t36_cell2);
            table36.addCell(t36_cell3);
            Paragraph p39= new Paragraph();
            p39.add(table36);
            
            // **43 Table contains subject G.K / V. Edu. and space for marks**
            PdfPTable table37 = new PdfPTable(3);
            table37.setWidthPercentage(70);
            PdfPCell t37_cell1 = new PdfPCell(new Phrase("G.K / V. Edu."));
            PdfPCell t37_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t37_cell3 = new PdfPCell(new Phrase("   "));
            t37_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t37_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t37_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t37_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t37_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t37_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table37.addCell(t37_cell1);
            table37.addCell(t37_cell2);
            table37.addCell(t37_cell3);
            Paragraph p40= new Paragraph();
            p40.add(table37);
            
            // **44 Table contains subject Music and space for marks**
            PdfPTable table38 = new PdfPTable(3);
            table38.setWidthPercentage(70);
            PdfPCell t38_cell1 = new PdfPCell(new Phrase("Music"));
            PdfPCell t38_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t38_cell3 = new PdfPCell(new Phrase("   "));
            t38_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t38_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t38_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t38_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t38_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t38_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table38.addCell(t38_cell1);
            table38.addCell(t38_cell2);
            table38.addCell(t38_cell3);
            Paragraph p41= new Paragraph();
            p41.add(table38);
            
            // Makes a new document and opens it
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document,file);
            document.open();
            
            // Add stuff to the document
            document.add(p1);           // **1 Holy Cross Header Image**
            document.add(p3);           // **2 Spacer**
            document.add(p2);           // **3 This table contains the main Title**
            document.add(p5);           // **4 Spacer**
            //  document.add();             // **5 Student's Photo**
            document.add(p4);           // **6 Table contains first line from Report card**
            document.add(p6);           // **7 Table contains secound line from Report card**
            document.add(p7);           // **8 Table contains third line from Report card**
            document.add(p8);           // **9 Table contains fourth line from Report card**
            document.add(p9);           // **10 Table contains fifth line from Report card**
            document.add(p10);          // **11 Table contains sixth line from Report card**
            document.add(p11);          // **12 Table contains seventh line from Report card**
            document.add(p12);          // **13 Table contains eighth line from Report card**
            document.add(p13);          // **14 Table contains ninth line from Report card**
            
            document.newPage();         // **15 Adds New Page
            document.add(p14);          // **16 Table contains title of new page - First Semester**
            document.add(p15);          // **17 Table contains coulmn names**
            document.add(p16);          // **18 Table contains subject English and space for marks**
            document.add(p17);          // **19 Table contains subject Marathi and space for marks**
            document.add(p18);          // **20 Table contains subject Hindi and space for marks**
            document.add(p19);          // **21 Table contains subject Maths and space for marks**
            document.add(p20);          // **22 Table contains subject G. Science and space for marks**
            document.add(p21);          // **23 Table contains subject EVS and space for marks**
            document.add(p22);          // **24 Table contains subject His/Geo and space for marks**
            document.add(p23);          // **25 Table contains subject Art / Craft and space for marks**
            document.add(p24);          // **26 Table contains subject Computer and space for marks**
            document.add(p25);          // **27 Table contains subject PT Science and space for marks**
            document.add(p26);          // **28 Table contains subject GK Science and space for marks**
            document.add(p27);          // **29 Table contains subject Music and space for marks**
            
            document.newPage();         // **30 Adds New Page
            document.add(p28);          // **31 Table contains title of new page - First Semester**
            document.add(p29);          // **32 Table contains coulmn names**
            document.add(p30);          // **33 Table contains subject English and space for marks**
            document.add(p31);          // **34 Table contains subject Marathi and space for marks**
            document.add(p32);          // **35 Table contains subject Hindi and space for marks**
            document.add(p33);          // **36 Table contains subject Maths and space for marks**
            document.add(p34);          // **37 Table contains subject G. Science and space for marks**
            document.add(p35);          // **38 Table contains subject EVS and space for marks**
            document.add(p36);          // **39 Table contains subject His/Geo and space for marks**
            document.add(p37);          // **40 Table contains subject Art / Craft and space for marks**
            document.add(p38);          // **41 Table contains subject Computer and space for marks**
            document.add(p39);          // **42 Table contains subject PT Science and space for marks**
            document.add(p40);          // **43 Table contains subject GK Science and space for marks**
            document.add(p41);          // **44 Table contains subject Music and space for marks**
            
            // Closes the document
            document.close();
            file.close();
            
            //printProgressReport_JR_FirstSem();
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
    }
//</editor-fold>
  
    //Method which prints Senior Semester 2nd Marksheet
    //<editor-fold defaultstate="collapsed" desc="PPR Senior Sem 2">
    public void printProgressReportSenior_Sem2(int std_id, String gr_no, String report_type, String name, String roll_no, String Stand, String std_div,
            String fname, String focc, String mname, String mocc, String mtongue, String medium, String dob, String age, String phone,
            String email, String prHno, String prBldgNo, String prStrName, String prCity, String prDistrict, String prState, String semester)
    {
        
        String imagePath = "D:\\Workspace_Netbeans\\DignitySMS_1\\images\\header.jpg";
        
        Image image = null;
        try
        {
            // Make stuff for the document
            
            // Makes the Image
            OutputStream file = new FileOutputStream(new File("C:\\Users\\admin\\Desktop\\Progressreport\\Report_"+std_id+"_"+gr_no+"_"+semester+"_"+report_type+".pdf"));
            image = Image.getInstance(imagePath);
            //image.setAlignment(Element.ALIGN_CENTER);
            //image.setAbsolutePosition(50f, 700f);
            //image.scaleAbsolute(500f, 100f);
            
            // **1 Holy Cross Header Image**
            PdfPTable table = new PdfPTable(1);
            table.setWidthPercentage(70);
            //table.setWidths(new float[]{2.6f,1.6f});
            table.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(image);
            table.setHorizontalAlignment(50);
            Paragraph p1= new Paragraph();
            p1.add(table);
            
            // **2 Spacer**
            Paragraph p3 = new Paragraph();
            addEmptyLine(p3, 1);
            
            // **3 This table contains the main Title**
            PdfPTable table1 = new PdfPTable(1);
            table1.setWidthPercentage(50);
            //table.setWidths(new float[]{2.6f,1.6f});
            table1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table1.setHorizontalAlignment(50);
            PdfPCell cell = new PdfPCell(new Phrase("CONTINUOS CUMULATIVE EVALUATION PROGRESS REPORT 2016-2017"));
            cell.setVerticalAlignment(Element.ALIGN_CENTER);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table1.addCell(cell);
            Paragraph p2= new Paragraph();
            p2.add(table1);
            
            // **4 Spacer**
            Paragraph p5 = new Paragraph();
            addEmptyLine(p5, 3);
            
            // **5 Student's Photo**
            
            // **6 Table contains first line from Report card**
            PdfPTable table2 = new PdfPTable(2);
            table2.setWidthPercentage(70);
            PdfPCell cellOne = new PdfPCell(new Phrase("Name: "+name+""));
            PdfPCell cellTwo = new PdfPCell(new Phrase("Roll No: "+roll_no+""));
            cellOne.setBorder(Rectangle.NO_BORDER);
            cellTwo.setBorder(Rectangle.NO_BORDER);
            table2.addCell(cellOne);
            table2.addCell(cellTwo);
            Paragraph p4= new Paragraph();
            p4.add(table2);
            
            // **7 Table contains secound line from Report card**
            PdfPTable table3 = new PdfPTable(2);
            table3.setWidthPercentage(70);
            PdfPCell t3_cell1 = new PdfPCell(new Phrase("STD: "+Stand+""));
            PdfPCell t3_cell2 = new PdfPCell(new Phrase("Division: "+std_div+""));
            //    PdfPCell t3_cell3 = new PdfPCell(new Phrase("G.R. No: "+gr_no+""));
            t3_cell1.setBorder(Rectangle.NO_BORDER);
            t3_cell2.setBorder(Rectangle.NO_BORDER);
            //    t3_cell3.setBorder(Rectangle.NO_BORDER);
            table3.addCell(t3_cell1);
            table3.addCell(t3_cell2);
            //    table3.addCell(t3_cell3);
            Paragraph p6= new Paragraph();
            p6.add(table3);
            
            // **8 Table contains third line from Report card**
            PdfPTable table4 = new PdfPTable(2);
            table4.setWidthPercentage(70);
            PdfPCell t4_cell1 = new PdfPCell(new Phrase("Father's Name: "+fname+""));
            PdfPCell t4_cell2 = new PdfPCell(new Phrase("Profession: "+focc+""));
            t4_cell1.setBorder(Rectangle.NO_BORDER);
            t4_cell2.setBorder(Rectangle.NO_BORDER);
            table4.addCell(t4_cell1);
            table4.addCell(t4_cell2);
            Paragraph p7= new Paragraph();
            p7.add(table4);
            
            // **9 Table contains fourth line from Report card**
            PdfPTable table5 = new PdfPTable(2);
            table5.setWidthPercentage(70);
            PdfPCell t5_cell1 = new PdfPCell(new Phrase("Mother's Name: "+mname+""));
            PdfPCell t5_cell2 = new PdfPCell(new Phrase("Profession: "+mocc+""));
            t5_cell1.setBorder(Rectangle.NO_BORDER);
            t5_cell2.setBorder(Rectangle.NO_BORDER);
            table5.addCell(t5_cell1);
            table5.addCell(t5_cell2);
            Paragraph p8= new Paragraph();
            p8.add(table5);
            
            // **10 Table contains fifth line from Report card**
            PdfPTable table6 = new PdfPTable(2);
            table6.setWidthPercentage(70);
            PdfPCell t6_cell1 = new PdfPCell(new Phrase("Mother Tongue: "+mtongue+""));
            PdfPCell t6_cell2 = new PdfPCell(new Phrase("Medium: "+medium+""));
            t6_cell1.setBorder(Rectangle.NO_BORDER);
            t6_cell2.setBorder(Rectangle.NO_BORDER);
            table6.addCell(t6_cell1);
            table6.addCell(t6_cell2);
            Paragraph p9= new Paragraph();
            p9.add(table6);
            
            // **11 Table contains sixth line from Report card**
            PdfPTable table7 = new PdfPTable(2);
            table7.setWidthPercentage(70);
            PdfPCell t7_cell1 = new PdfPCell(new Phrase("Date of Birth: "+dob+""));
            PdfPCell t7_cell2 = new PdfPCell(new Phrase("Age: "+age+""));
            t7_cell1.setBorder(Rectangle.NO_BORDER);
            t7_cell2.setBorder(Rectangle.NO_BORDER);
            table7.addCell(t7_cell1);
            table7.addCell(t7_cell2);
            Paragraph p10= new Paragraph();
            p10.add(table7);
            
            // **12 Table contains seventh line from Report card**
            PdfPTable table8 = new PdfPTable(1);
            table8.setWidthPercentage(70);
            PdfPCell t8_cell1 = new PdfPCell(new Phrase("Address: "+prHno+" "+prBldgNo+" "+prStrName+""));
            t8_cell1.setBorder(Rectangle.NO_BORDER);
            table8.addCell(t8_cell1);
            Paragraph p11= new Paragraph();
            p11.add(table8);
            
            // **13 Table contains eighth line from Report card**
            PdfPTable table9 = new PdfPTable(1);
            table9.setWidthPercentage(70);
            PdfPCell t9_cell1 = new PdfPCell(new Phrase("Telephone No: "+phone+""));
            t9_cell1.setBorder(Rectangle.NO_BORDER);
            table9.addCell(t9_cell1);
            Paragraph p12= new Paragraph();
            p12.add(table9);
            
            // **14 Table contains ninth line from Report card**
            PdfPTable table10 = new PdfPTable(1);
            table10.setWidthPercentage(70);
            PdfPCell t10_cell1 = new PdfPCell(new Phrase("Email Id: "+email+""));
            t10_cell1.setBorder(Rectangle.NO_BORDER);
            table10.addCell(t10_cell1);
            Paragraph p13= new Paragraph();
            p13.add(table10);
            
            // **15 Adds New Page
            
            // **16 Table contains title of new page - First Semester**
            PdfPTable table11 = new PdfPTable(1);
            table11.setWidthPercentage(70);
            PdfPCell t11_cell1 = new PdfPCell(new Phrase("First Semester"));
            t11_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t11_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table11.addCell(t11_cell1);
            Paragraph p14= new Paragraph();
            p14.add(table11);
            
            // **17 Table contains coulmn names**
            PdfPTable table12 = new PdfPTable(3);
            table12.setWidthPercentage(70);
            PdfPCell t12_cell1 = new PdfPCell(new Phrase("Subject"));
            PdfPCell t12_cell2 = new PdfPCell(new Phrase("Marks"));
            PdfPCell t12_cell3 = new PdfPCell(new Phrase("Descriptive Detail"));
            t12_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t12_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t12_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t12_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t12_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t12_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table12.addCell(t12_cell1);
            table12.addCell(t12_cell2);
            table12.addCell(t12_cell3);
            Paragraph p15= new Paragraph();
            p15.add(table12);
            
            // **18 Table contains subject English and space for marks**
            PdfPTable table13 = new PdfPTable(3);
            table13.setWidthPercentage(70);
            PdfPCell t13_cell1 = new PdfPCell(new Phrase("English"));
            PdfPCell t13_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t13_cell3 = new PdfPCell(new Phrase("   "));
            t13_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t13_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t13_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t13_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t13_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t13_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table13.addCell(t13_cell1);
            table13.addCell(t13_cell2);
            table13.addCell(t13_cell3);
            Paragraph p16= new Paragraph();
            p16.add(table13);
            
            // **19 Table contains subject Marathi and space for marks**
            PdfPTable table14 = new PdfPTable(3);
            table14.setWidthPercentage(70);
            PdfPCell t14_cell1 = new PdfPCell(new Phrase("Marathi"));
            PdfPCell t14_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t14_cell3 = new PdfPCell(new Phrase("   "));
            t14_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t14_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t14_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t14_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t14_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t14_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table14.addCell(t14_cell1);
            table14.addCell(t14_cell2);
            table14.addCell(t14_cell3);
            Paragraph p17= new Paragraph();
            p17.add(table14);
            
            // **20 Table contains subject Hindi and space for marks**
            PdfPTable table15 = new PdfPTable(3);
            table15.setWidthPercentage(70);
            PdfPCell t15_cell1 = new PdfPCell(new Phrase("Hindi"));
            PdfPCell t15_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t15_cell3 = new PdfPCell(new Phrase("   "));
            t15_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t15_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t15_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t15_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t15_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t15_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table15.addCell(t15_cell1);
            table15.addCell(t15_cell2);
            table15.addCell(t15_cell3);
            Paragraph p18= new Paragraph();
            p18.add(table15);
            
            // **21 Table contains subject Maths and space for marks**
            PdfPTable table16 = new PdfPTable(3);
            table16.setWidthPercentage(70);
            PdfPCell t16_cell1 = new PdfPCell(new Phrase("Maths"));
            PdfPCell t16_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t16_cell3 = new PdfPCell(new Phrase("   "));
            t16_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t16_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t16_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t16_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t16_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t16_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table16.addCell(t16_cell1);
            table16.addCell(t16_cell2);
            table16.addCell(t16_cell3);
            Paragraph p19= new Paragraph();
            p19.add(table16);
            
            // **22 Table contains subject G. Science and space for marks**
            PdfPTable table17 = new PdfPTable(3);
            table17.setWidthPercentage(70);
            PdfPCell t17_cell1 = new PdfPCell(new Phrase("G. Science"));
            PdfPCell t17_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t17_cell3 = new PdfPCell(new Phrase("   "));
            t17_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t17_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t17_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t17_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t17_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t17_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table17.addCell(t17_cell1);
            table17.addCell(t17_cell2);
            table17.addCell(t17_cell3);
            Paragraph p20= new Paragraph();
            p20.add(table17);
            
            // **23 Table contains subject EVS and space for marks**
            PdfPTable table18 = new PdfPTable(3);
            table18.setWidthPercentage(70);
            PdfPCell t18_cell1 = new PdfPCell(new Phrase("EVS"));
            PdfPCell t18_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t18_cell3 = new PdfPCell(new Phrase("   "));
            t18_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t18_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t18_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t18_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t18_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t18_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table18.addCell(t18_cell1);
            table18.addCell(t18_cell2);
            table18.addCell(t18_cell3);
            Paragraph p21= new Paragraph();
            p21.add(table18);
            
            // **24 Table contains subject History / Geography and space for marks**
            PdfPTable table19 = new PdfPTable(3);
            table19.setWidthPercentage(70);
            PdfPCell t19_cell1 = new PdfPCell(new Phrase("History / Geography"));
            PdfPCell t19_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t19_cell3 = new PdfPCell(new Phrase("   "));
            t19_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t19_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t19_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t19_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t19_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t19_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table19.addCell(t19_cell1);
            table19.addCell(t19_cell2);
            table19.addCell(t19_cell3);
            Paragraph p22= new Paragraph();
            p22.add(table19);
            
            // **25 Table contains subject Art / Craft and space for marks**
            PdfPTable table20 = new PdfPTable(3);
            table20.setWidthPercentage(70);
            PdfPCell t20_cell1 = new PdfPCell(new Phrase("Art / Craft"));
            PdfPCell t20_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t20_cell3 = new PdfPCell(new Phrase("   "));
            t20_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t20_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t20_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t20_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t20_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t20_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table20.addCell(t20_cell1);
            table20.addCell(t20_cell2);
            table20.addCell(t20_cell3);
            Paragraph p23= new Paragraph();
            p23.add(table20);
            
            // **26 Table contains subject Computer and space for marks**
            PdfPTable table21 = new PdfPTable(3);
            table21.setWidthPercentage(70);
            PdfPCell t21_cell1 = new PdfPCell(new Phrase("Computer"));
            PdfPCell t21_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t21_cell3 = new PdfPCell(new Phrase("   "));
            t21_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t21_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t21_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t21_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t21_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t21_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table21.addCell(t21_cell1);
            table21.addCell(t21_cell2);
            table21.addCell(t21_cell3);
            Paragraph p24= new Paragraph();
            p24.add(table21);
            
            // **27 Table contains subject P. T. and space for marks**
            PdfPTable table22 = new PdfPTable(3);
            table22.setWidthPercentage(70);
            PdfPCell t22_cell1 = new PdfPCell(new Phrase("P. T."));
            PdfPCell t22_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t22_cell3 = new PdfPCell(new Phrase("   "));
            t22_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t22_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t22_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t22_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t22_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t22_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table22.addCell(t22_cell1);
            table22.addCell(t22_cell2);
            table22.addCell(t22_cell3);
            Paragraph p25= new Paragraph();
            p22.add(table22);
            
            // **28 Table contains subject G.K / V. Edu. and space for marks**
            PdfPTable table23 = new PdfPTable(3);
            table23.setWidthPercentage(70);
            PdfPCell t23_cell1 = new PdfPCell(new Phrase("G.K / V. Edu."));
            PdfPCell t23_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t23_cell3 = new PdfPCell(new Phrase("   "));
            t23_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t23_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t23_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t23_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t23_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t23_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table23.addCell(t23_cell1);
            table23.addCell(t23_cell2);
            table23.addCell(t23_cell3);
            Paragraph p26= new Paragraph();
            p26.add(table23);
            
            // **29 Table contains subject Music and space for marks**
            PdfPTable table24 = new PdfPTable(3);
            table24.setWidthPercentage(70);
            PdfPCell t24_cell1 = new PdfPCell(new Phrase("Music"));
            PdfPCell t24_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t24_cell3 = new PdfPCell(new Phrase("   "));
            t24_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t24_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t24_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t24_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t24_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t24_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table24.addCell(t24_cell1);
            table24.addCell(t24_cell2);
            table24.addCell(t24_cell3);
            Paragraph p27= new Paragraph();
            p27.add(table24);
            
            // **30 Adds New Page
            
            // **31 Table contains title of new page - Second Semester**
            PdfPTable table25 = new PdfPTable(1);
            table25.setWidthPercentage(70);
            PdfPCell t25_cell1 = new PdfPCell(new Phrase("Second Semester"));
            t25_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t25_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            table25.addCell(t25_cell1);
            Paragraph p28= new Paragraph();
            p28.add(table25);
            
            // **32 Table contains coulmn names**
            PdfPTable table26 = new PdfPTable(3);
            table26.setWidthPercentage(70);
            PdfPCell t26_cell1 = new PdfPCell(new Phrase("Subject"));
            PdfPCell t26_cell2 = new PdfPCell(new Phrase("Marks"));
            PdfPCell t26_cell3 = new PdfPCell(new Phrase("Descriptive Detail"));
            t26_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t26_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t26_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t26_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t26_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t26_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table26.addCell(t26_cell1);
            table26.addCell(t26_cell2);
            table26.addCell(t26_cell3);
            Paragraph p29= new Paragraph();
            p29.add(table26);
            
            // **33 Table contains subject English and space for marks**
            PdfPTable table27 = new PdfPTable(3);
            table27.setWidthPercentage(70);
            PdfPCell t27_cell1 = new PdfPCell(new Phrase("English"));
            PdfPCell t27_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t27_cell3 = new PdfPCell(new Phrase("   "));
            t27_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t27_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t27_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t27_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t27_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t27_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table27.addCell(t27_cell1);
            table27.addCell(t27_cell2);
            table27.addCell(t27_cell3);
            Paragraph p30= new Paragraph();
            p30.add(table27);
            
            // **34 Table contains subject Marathi and space for marks**
            PdfPTable table28 = new PdfPTable(3);
            table28.setWidthPercentage(70);
            PdfPCell t28_cell1 = new PdfPCell(new Phrase("Marathi"));
            PdfPCell t28_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t28_cell3 = new PdfPCell(new Phrase("   "));
            t28_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t28_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t28_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t28_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t28_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t28_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table28.addCell(t28_cell1);
            table28.addCell(t28_cell2);
            table28.addCell(t28_cell3);
            Paragraph p31= new Paragraph();
            p31.add(table28);
            
            // **35 Table contains subject Hindi and space for marks**
            PdfPTable table29 = new PdfPTable(3);
            table29.setWidthPercentage(70);
            PdfPCell t29_cell1 = new PdfPCell(new Phrase("Hindi"));
            PdfPCell t29_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t29_cell3 = new PdfPCell(new Phrase("   "));
            t29_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t29_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t29_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t29_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t29_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t29_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table29.addCell(t29_cell1);
            table29.addCell(t29_cell2);
            table29.addCell(t29_cell3);
            Paragraph p32= new Paragraph();
            p32.add(table29);
            
            // **36 Table contains subject Maths and space for marks**
            PdfPTable table30 = new PdfPTable(3);
            table30.setWidthPercentage(70);
            PdfPCell t30_cell1 = new PdfPCell(new Phrase("Maths"));
            PdfPCell t30_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t30_cell3 = new PdfPCell(new Phrase("   "));
            t30_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t30_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t30_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t30_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t30_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t30_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table30.addCell(t30_cell1);
            table30.addCell(t30_cell2);
            table30.addCell(t30_cell3);
            Paragraph p33= new Paragraph();
            p33.add(table30);
            
            // **37 Table contains subject G. Science and space for marks**
            PdfPTable table31 = new PdfPTable(3);
            table31.setWidthPercentage(70);
            PdfPCell t31_cell1 = new PdfPCell(new Phrase("G. Science"));
            PdfPCell t31_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t31_cell3 = new PdfPCell(new Phrase("   "));
            t31_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t31_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t31_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t31_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t31_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t31_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table31.addCell(t31_cell1);
            table31.addCell(t31_cell2);
            table31.addCell(t31_cell3);
            Paragraph p34= new Paragraph();
            p34.add(table31);
            
            // **38 Table contains subject EVS and space for marks**
            PdfPTable table32 = new PdfPTable(3);
            table32.setWidthPercentage(70);
            PdfPCell t32_cell1 = new PdfPCell(new Phrase("EVS"));
            PdfPCell t32_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t32_cell3 = new PdfPCell(new Phrase("   "));
            t32_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t32_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t32_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t32_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t32_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t32_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table32.addCell(t32_cell1);
            table32.addCell(t32_cell2);
            table32.addCell(t32_cell3);
            Paragraph p35= new Paragraph();
            p35.add(table32);
            
            // **39 Table contains subject History / Geography and space for marks**
            PdfPTable table33 = new PdfPTable(3);
            table33.setWidthPercentage(70);
            PdfPCell t33_cell1 = new PdfPCell(new Phrase("History / Geography"));
            PdfPCell t33_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t33_cell3 = new PdfPCell(new Phrase("   "));
            t33_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t33_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t33_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t33_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t33_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t33_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table33.addCell(t33_cell1);
            table33.addCell(t33_cell2);
            table33.addCell(t33_cell3);
            Paragraph p36= new Paragraph();
            p36.add(table33);
            
            // **40 Table contains subject Art / Craft and space for marks**
            PdfPTable table34 = new PdfPTable(3);
            table34.setWidthPercentage(70);
            PdfPCell t34_cell1 = new PdfPCell(new Phrase("Art / Craft"));
            PdfPCell t34_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t34_cell3 = new PdfPCell(new Phrase("   "));
            t34_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t34_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t34_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t34_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t34_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t34_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table34.addCell(t34_cell1);
            table34.addCell(t34_cell2);
            table34.addCell(t34_cell3);
            Paragraph p37= new Paragraph();
            p37.add(table34);
            
            // **41 Table contains subject Computer and space for marks**
            PdfPTable table35 = new PdfPTable(3);
            table35.setWidthPercentage(70);
            PdfPCell t35_cell1 = new PdfPCell(new Phrase("Computer"));
            PdfPCell t35_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t35_cell3 = new PdfPCell(new Phrase("   "));
            t35_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t35_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t35_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t35_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t35_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t35_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table35.addCell(t35_cell1);
            table35.addCell(t35_cell2);
            table35.addCell(t35_cell3);
            Paragraph p38= new Paragraph();
            p38.add(table35);
            
            // **42 Table contains subject P. T. and space for marks**
            PdfPTable table36 = new PdfPTable(3);
            table36.setWidthPercentage(70);
            PdfPCell t36_cell1 = new PdfPCell(new Phrase("P. T."));
            PdfPCell t36_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t36_cell3 = new PdfPCell(new Phrase("   "));
            t36_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t36_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t36_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t36_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t36_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t36_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table36.addCell(t36_cell1);
            table36.addCell(t36_cell2);
            table36.addCell(t36_cell3);
            Paragraph p39= new Paragraph();
            p39.add(table36);
            
            // **43 Table contains subject G.K / V. Edu. and space for marks**
            PdfPTable table37 = new PdfPTable(3);
            table37.setWidthPercentage(70);
            PdfPCell t37_cell1 = new PdfPCell(new Phrase("G.K / V. Edu."));
            PdfPCell t37_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t37_cell3 = new PdfPCell(new Phrase("   "));
            t37_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t37_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t37_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t37_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t37_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t37_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table37.addCell(t37_cell1);
            table37.addCell(t37_cell2);
            table37.addCell(t37_cell3);
            Paragraph p40= new Paragraph();
            p40.add(table37);
            
            // **44 Table contains subject Music and space for marks**
            PdfPTable table38 = new PdfPTable(3);
            table38.setWidthPercentage(70);
            PdfPCell t38_cell1 = new PdfPCell(new Phrase("Music"));
            PdfPCell t38_cell2 = new PdfPCell(new Phrase("   "));
            PdfPCell t38_cell3 = new PdfPCell(new Phrase("   "));
            t38_cell1.setVerticalAlignment(Element.ALIGN_CENTER);
            t38_cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            t38_cell2.setVerticalAlignment(Element.ALIGN_CENTER);
            t38_cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            t38_cell3.setVerticalAlignment(Element.ALIGN_CENTER);
            t38_cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            table38.addCell(t38_cell1);
            table38.addCell(t38_cell2);
            table38.addCell(t38_cell3);
            Paragraph p41= new Paragraph();
            p41.add(table38);
            
            // Makes a new document and opens it
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document,file);
            document.open();
            
            // Add stuff to the document
            document.add(p1);           // **1 Holy Cross Header Image**
            document.add(p3);           // **2 Spacer**
            document.add(p2);           // **3 This table contains the main Title**
            document.add(p5);           // **4 Spacer**
            //  document.add();             // **5 Student's Photo**
            document.add(p4);           // **6 Table contains first line from Report card**
            document.add(p6);           // **7 Table contains secound line from Report card**
            document.add(p7);           // **8 Table contains third line from Report card**
            document.add(p8);           // **9 Table contains fourth line from Report card**
            document.add(p9);           // **10 Table contains fifth line from Report card**
            document.add(p10);          // **11 Table contains sixth line from Report card**
            document.add(p11);          // **12 Table contains seventh line from Report card**
            document.add(p12);          // **13 Table contains eighth line from Report card**
            document.add(p13);          // **14 Table contains ninth line from Report card**
            
            document.newPage();         // **15 Adds New Page
            document.add(p14);          // **16 Table contains title of new page - First Semester**
            document.add(p15);          // **17 Table contains coulmn names**
            document.add(p16);          // **18 Table contains subject English and space for marks**
            document.add(p17);          // **19 Table contains subject Marathi and space for marks**
            document.add(p18);          // **20 Table contains subject Hindi and space for marks**
            document.add(p19);          // **21 Table contains subject Maths and space for marks**
            document.add(p20);          // **22 Table contains subject G. Science and space for marks**
            document.add(p21);          // **23 Table contains subject EVS and space for marks**
            document.add(p22);          // **24 Table contains subject His/Geo and space for marks**
            document.add(p23);          // **25 Table contains subject Art / Craft and space for marks**
            document.add(p24);          // **26 Table contains subject Computer and space for marks**
            document.add(p25);          // **27 Table contains subject PT Science and space for marks**
            document.add(p26);          // **28 Table contains subject GK Science and space for marks**
            document.add(p27);          // **29 Table contains subject Music and space for marks**
            
            document.newPage();         // **30 Adds New Page
            document.add(p28);          // **31 Table contains title of new page - First Semester**
            document.add(p29);          // **32 Table contains coulmn names**
            document.add(p30);          // **33 Table contains subject English and space for marks**
            document.add(p31);          // **34 Table contains subject Marathi and space for marks**
            document.add(p32);          // **35 Table contains subject Hindi and space for marks**
            document.add(p33);          // **36 Table contains subject Maths and space for marks**
            document.add(p34);          // **37 Table contains subject G. Science and space for marks**
            document.add(p35);          // **38 Table contains subject EVS and space for marks**
            document.add(p36);          // **39 Table contains subject His/Geo and space for marks**
            document.add(p37);          // **40 Table contains subject Art / Craft and space for marks**
            document.add(p38);          // **41 Table contains subject Computer and space for marks**
            document.add(p39);          // **42 Table contains subject PT Science and space for marks**
            document.add(p40);          // **43 Table contains subject GK Science and space for marks**
            document.add(p41);          // **44 Table contains subject Music and space for marks**
            
            // Closes the document
            document.close();
            file.close();
            
            //printProgressReport_JR_FirstSem();
            
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
    }
//</editor-fold>
    
    // Method which adds space to the document
    private static void addEmptyLine(Paragraph paragraph, int number) {
    for (int i = 0; i < number; i++) {
      paragraph.add(new Paragraph("   "));
    }
  }
  
}
