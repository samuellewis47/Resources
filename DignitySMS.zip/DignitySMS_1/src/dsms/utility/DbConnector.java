package dsms.utility;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnector {
	
	   public Connection dbcon(){
		Connection con=null;
		try
    	{  
    		Class.forName("com.mysql.jdbc.Driver");  
    		con=DriverManager.getConnection("jdbc:mysql://localhost:3307/dignitysms","root","admin");
    	} 
		
	catch(Exception e)
		{
		  e.printStackTrace();
		}
		if(con!=null)
		{
			System.out.println("Connection has been established successfully");
		}
		else
		{
			System.out.print("Connection has not been established");
		}
		return con;
		
		
	}

}
